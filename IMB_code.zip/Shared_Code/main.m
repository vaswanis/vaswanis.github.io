clear;
clc;
close all;

addpath(genpath('./Data'));
addpath(genpath('./gaimc'));
addpath(genpath('./prettyPlot'));
addpath(genpath('./Results'));

% implementing UCB
% ----------------- parameters ------------------------------------------ %
% ------------------- if generating graph --------------------------------%
% number of nodes
n = 50;

%number of components - if using synthetic graph
num_components = 5;

% maximum influence probability in the network, = 0 if using 1 / in-degree
pmax = 0.1;
% ------------------- if generating graph --------------------------------%

%type of the graph
graph_type = 5;

if graph_type < 4
    dataset = ['synthetic_' num2str(graph_type) '_' num2str(n) '_' num2str(pmax) '_' num2str(num_components)];
elseif graph_type == 5
    dataset = 'facebook';
    n = 347;
elseif graph_type == 6
    dataset = 'nethept';
elseif graph_type == 7
    dataset = 'facebook-combined';
    n = 4039;
elseif graph_type == 8
    dataset = 'flixster';
    n = 29358; 
elseif graph_type == 9
    dataset = 'wiki';
    n = 8299; 
else
    disp('Error');
    pause;
end

%number of rounds
T = 500;

% number of runs
no_runs = 3;

% diffusion model 
% = 1 for IC; = 2 for LT
diffusion_model = 1;

% spread computation model = 1 for IC, = 2 for LT, = 3 for both
spread_computation_model = 1;

% number of models for conventional IM
if spread_computation_model > 2
	num_models = 2; % = IC and LT
else 
	num_models = 1;
end

% laplacian regularization parameter
lambda_1 = 1e-4;

% for lazy evaluations
allowed_approximation = 0;

% ---- offline IM parameters ---------------------------------------------%
% number of mcmc simulations to calculate expected spread
no_of_mcmc_simulations = 1000;
% ---- offline IM parameters ---------------------------------------------%

% flag for profiling code
profile_code = 1;

% whether to compare against CUCB
compare_CUCB = 1;

% whether to run the CUCB algorithm
run_CUCB = 1;

% whether to read cascades from file
stored_cascades = 1;

% ------------ parameters to be varied ---------------------------------- %
K_list = [10];
if compare_CUCB == 0
	% use bottom d eigenvectors for approximation
	d_list = [10];
else
	% tabular case when comparing against CUCB 
	%d_list = [n];
	d_list = [10];
end
% ----------------------------------------------------------------------- %

% ----------------------------------------------------------------------- %
% initialize regret for all methods
regret_1 = zeros(T,no_runs);
CUCB_regret = zeros(T,no_runs,num_models);

per_step_reward_1 = zeros(T,no_runs);
CUCB_reward = zeros(T,no_runs,num_models);

CUCB_time = zeros(no_runs,num_models);
% ----------------------------------------------------------------------- %

% ----------------------------------------------------------------------- %
if graph_type > 4

	% copy attribute file into ./
	cmd = ['cp ./Data/' dataset '/attribute.txt ' './'];
	system(cmd);

end
% ----------------------------------------------------------------------- %

for d = d_list

	for K = K_list

		for run = 1:no_runs 

		fprintf('---------------- Run %d----------------------------\n', run);

		% ----------------------------------------------------------------------- %
		% create graph
		[A,P,comm_size] = create_graph(n,pmax,num_components,graph_type);

		if graph_type > 4
		    n = comm_size;
		end

		% ----------------- write graph with new probabilities to graph_ic.inf in ./ folder --% 
		[row col v] = find(P);                                   
		dlmwrite('./graph_ic.inf',[row col v], 'delimiter', ' ');		
		% ------------------------------------------------------------------------------------% 

		% construct laplacian L
		L1 = speye(n);
		L2 = construct_laplacian(A);

		% eigendecomposition of L
		if compare_CUCB == 0       
			% using features from the Laplacian
        		[U,Sigma] = eigs(L2,d,'sm');
		else
		       	%tabular case - each edge is treated independently
		        %U = speye(d);
        		[U,Sigma] = eigs(L2,d,'sm');
		 end

	        % creating node features: psi - d x n matrix
		psi = U';
    
		% generate covariance matrix: cov - d x d matrix
   		cov = psi * psi';
    
		% calculate psi norms - only for Laplacian features
		psi_norms = sum(abs(psi).^2,1);
    
		if compare_CUCB == 1

			if run_CUCB == 1

				disp('Running CUCB')
				[cascades,CUCB_spread,CUCB_time(run,:)] = CUCB(dataset, K, T,diffusion_model,spread_computation_model);

				 % rename for later use 
			         results_fname =  ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_CUCB_results.log'];
			         results_fname_new =  ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_' num2str(run) '_CUCB_results.log'];
			         system( ['mv ' results_fname ' ' results_fname_new] );

				 % rename for later use 
				 cascades_fname = ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_cascades.txt'];
				 cascades_fname_new = ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_'  num2str(run) '_cascades.txt'];
				 system( ['mv ' cascades_fname ' ' cascades_fname_new] );

			else

				results_fname =  ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_' num2str(run) '_CUCB_results.log'];
				[CUCB_spread,CUCB_time] = process_CUCB_results(results_fname);
	
			        % cascades need to be stored in order to compare against CUCB 	
				cascades_fname_new = ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_'  num2str(run) '_cascades.txt'];
				cascades_fname = [dataset '_' num2str(K) '_' num2str(T) '_'  num2str(run) '_cascades.txt'];
				[ cascades ] = process_cascades( cascades_fname, T );
	
			end

	      else

			if stored_cascades == 1

				cascades_fname = [dataset '_' num2str(K) '_' num2str(T) '_'  num2str(run) '_cascades.txt'];
				[ cascades ] = process_cascades( cascades_fname, T );

			end

	      end

	     % -------- IM with full information---------------------------------------%
	     % finding the true optimal seed set
	     S_offline = select_offline_seeds(A,P,K,diffusion_model);
             disp('Full information influence maximization done');           
        
       	     % offline seed set
	     S_true = S_offline(1:K);
        
             % inverse of the covariance matrix
             inv_cov_1 = (1/lambda_1) * speye(n);
            
            % -----------initialization---------------------------------------------- %
            % initializing weights to be learnt for method 1
            alpha_1_hat = zeros(d,n);
            
            % initialize b = phi' * Y
            b1 = zeros(d * n,1);
            
            % initializing freq of s being a source node
            freq1 = zeros(n,1) * 1e-3;

            % initialize seed set
            S_learnt_1 = zeros(K,1);
            
            % initialize UCB
            UCB_1 = zeros(n);
            
            % initialize cov_det
            cov_det_1 = sum(log(diag(L1)));
            
            % lazy evaluation flags
            be_lazy_1 = 0;
            
            last_not_lazy_value_1 = cov_det_1;
            
            % profiling counters
            t_IM = 0;
            t_cascade = 0;
            t_calspread = 0;
            t_update = 0;
            t_est = 0;
            t_MAB = 0;
            % ------------------------------------------------------------------- %
            
            t_start = clock;
            for t = 1:T
                
                % select seed sets according to estimates
                t1 = clock;
                [S_learnt_1,UCB_1] = select_online_seeds(K,alpha_1_hat,inv_cov_1,psi,psi_norms,freq1,be_lazy_1,UCB_1,1,t);
                t2 = clock;
                if profile_code == 1
                    t_IM = t_IM + etime(t2,t1);
                end
                
                % simulate cascade
                t1 = clock;
                if stored_cascades == 0
                    [draw] = simulate_cascade(A,P);
                else
                    temp = cascades{t};
                    temp = reshape( temp, [2 size(temp,2)/2])';
                    draw = sparse(temp(:, 1), temp(:, 2), 1, n,n);
                end
                
                t2 = clock;
                if profile_code == 1
                    t_cascade = t_cascade + etime(t2,t1);
                end
                
                % calculate true spreads
                t1 = clock;
                spread_true = calculate_true_spread(S_true,draw);
                spread_1 = calculate_true_spread(S_learnt_1,draw);
                t2 = clock;
                if profile_code == 1
                    t_calspread = t_calspread + etime(t2,t1);
                end
                
                % update regret
                if t ~= 1
                    
                    regret_1(t,run) = regret_1(t-1,run) + (spread_true - spread_1);
                    per_step_reward_1(t,run) = per_step_reward_1(t-1,run) + spread_1;

		    if compare_CUCB == 1
                    	CUCB_regret(t,run,:) = CUCB_regret(t-1,run,:) + shiftdim( repmat( spread_true,[1 num_models] )  - CUCB_spread(t,:), -1 );
                    	CUCB_reward(t,run,:) = CUCB_reward(t-1,run,:) + shiftdim( CUCB_spread(t,:), -1 );
		    end

                else
                    
                    regret_1(t,run) =  (spread_true - spread_1);
                    per_step_reward_1(t,run) = spread_1;

		    if compare_CUCB == 1
                    	CUCB_regret(t,run,:) = shiftdim( repmat( spread_true,[1 num_models] )  - CUCB_spread(t,:), -1);
                    	CUCB_reward(t,run,:) = shiftdim( CUCB_spread(t,:), -1 );
		    end

                end
                
                % update parameters
                t1 = clock;
                [b1,freq1,inv_cov_1,cov_det_1] = updat(draw,S_learnt_1,psi,b1,freq1,inv_cov_1,cov_det_1);
                t2 = clock;
                if profile_code == 1
                    t_update = t_update + etime(t2,t1);
                end
                
                % estimate parameters
                t1 = clock;
                [alpha_1_hat] = estimate(inv_cov_1,b1,n,d);
                t2 = clock;
                if profile_code == 1
                    t_est = t_est + etime(t2,t1);
                end
                
                if mod(t,1) == 0
			if compare_CUCB == 1

                	    fprintf('Round %d: Spread: DiLinUCB = %f; CUCB = %f, True = %f\n',t, spread_1,CUCB_spread(t),spread_true);
	                    fprintf('Round %d: Cumulative Regret: DiLinUCB = %f; CUCB = %f\n',t, regret_1(t,run), CUCB_regret(t,run,:) );
        	            fprintf('Round %d: Average Regret: DiLinUCB = %f; CUCB = %f\n',t, regret_1(t,run)/t, CUCB_regret(t,run,:)/t );
			else
                	    fprintf('Round %d: Spread: DiLinUCB = %f; True = %f\n',t, spread_1,spread_true);
	                    fprintf('Round %d: Cumulative Regret: DiLinUCB = %f\n',t, regret_1(t,run));
        	            fprintf('Round %d: Average Regret: DiLinUCB = %f\n',t, regret_1(t,run)/t);
			end
                end
                
                % decide to be lazy or not
                approximation_factor_1 = d * (cov_det_1 - last_not_lazy_value_1);
                
                if approximation_factor_1 > log(1 + allowed_approximation * K * n)
                    be_lazy_1 = 0;
                    last_not_lazy_value_1 = cov_det_1;
                else
                    be_lazy_1 = 1;
                end
                
            end
            t_end = clock;

            if profile_code == 1
                fprintf('Average running times: IM = %f,Cascade simulation = %f, Spread calculation = %f, Parameter update = %f, Parameter estimation = %f\n',t_IM, t_cascade,t_calspread,t_update,t_est);
            end
            
	fprintf('-------------------------- End of run %d ------------------------\n', run); 
		
	end
        
        % average across runs and collect
        regret_1 = mean(regret_1,2);
        
        per_step_reward_1 = mean(per_step_reward_1,2);
        
        if compare_CUCB == 1
            CUCB_regret = (shiftdim(mean(CUCB_regret,2),2));
            CUCB_reward = (shiftdim(mean(CUCB_reward,2),2));

        end

        if compare_CUCB == 0
            
            regret = [regret_1];
            av_regret = [regret_1 ./ (1:T)'];
            per_step_reward = [per_step_reward_1 ./ (1:T)'];
            
        else
            
            regret = [regret_1 CUCB_regret];
            av_regret = [ regret_1 ./ (1:T)' CUCB_regret ./  repmat( (1:T)', [1 num_models] ) ];
            per_step_reward = [per_step_reward_1 ./ (1:T)' CUCB_reward ./ repmat( (1:T)', [1 num_models]) ];
            
        end
        
        % ----------------------plotting----------------------------------------- %
        fig_prefix = [dataset '_' num2str(K) '_' num2str(d) '_' num2str(lambda_1) '_' num2str(T) '_' num2str(no_runs)];
        
        % plot regret
        fig_name = ['./Results/' fig_prefix '_cumulative-regret.png'];
        plot_metrics(regret,fig_name,1,compare_CUCB,spread_computation_model);
        
        % plot average regret
        fig_name = ['./Results/' fig_prefix '_average-regret.png'];
        plot_metrics(av_regret,fig_name,2,compare_CUCB,spread_computation_model);
        
        % plot per step reward
        fig_name = ['./Results/' fig_prefix '_per-step-reward.png'];
        plot_metrics(per_step_reward,fig_name,3,compare_CUCB,spread_computation_model);
        
        % save the workspace
        workspace_name = ['./Results/' fig_prefix '_workspace.mat'];
        save(workspace_name);
        % ----------------------------------------------------------------------- %
    end

end
