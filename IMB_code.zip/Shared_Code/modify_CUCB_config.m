function [] = modify_CUCB_config(dataset, K, T, diffusion_model, spread_computation_model)

fname = './IMB/config.txt';
f = fopen(fname,'r');

A = {};
count = 1;
while(~feof(f))
    
    s = fgetl(f);
    l = strsplit(s);
    
    if(strcmp(l{1},'dataset') == 1)
        l{2} = dataset;
        s = [l{1} ' ' l{2}];
    end
    
    if(strcmp(l{1},'k') == 1)
        l{2} = num2str(K);
        s = [l{1} ' ' l{2}];
    end
    
    if(strcmp(l{1},'rounds') == 1)
        l{2} = num2str(T);
        s = [l{1} ' ' l{2}];
    end
    
    if(strcmp(l{1},'diffusion_model') == 1)
        l{2} = num2str(diffusion_model);
        s = [l{1} ' ' l{2}];
    end
    
    if(strcmp(l{1},'spread_computation_model') == 1)
        l{2} = num2str(spread_computation_model);
        s = [l{1} ' ' l{2}];
    end
    
    A{count} = [s];
    count = count + 1;
end
fclose(f);

gname = fname;
g = fopen(gname,'w');
for i = 1:count-1
    fprintf(g,'%s\r\n',A{i});
end
fclose(g);

end
