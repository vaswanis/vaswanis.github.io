function [CUCB_spread,CUCB_time] = process_CUCB_results(fname)

A = dlmread(fname,',');

temp = A(:,2:end);
CUCB_spread = temp(1:end-1,:);
CUCB_time = temp(end,:);

end
