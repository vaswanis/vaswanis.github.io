function [S,UCB] = select_online_seeds(K,alpha,inv_cov,psi,psi_norms, freq,be_lazy,prev_UCB,flag,t)

d = size(psi,1);
n = size(psi,2);

S = zeros(K,1);
prev_spread = 0;

mean_influence = alpha' * psi;
if be_lazy == 0

    inv_cov_d = diag(inv_cov);
    UCB = sqrt(inv_cov_d * psi_norms);	
    temp = 1 ./ sqrt(freq);
    c = sqrt(1.5 * log(t+1)) * repmat(temp, [1 n]);
    UCB = c' .* UCB + 1e-6 * rand(n);
    
else
    UCB = prev_UCB;
end

% computing the UCB on the influence
influence_UCB = mean_influence + UCB;

% project onto [0,1] interval
influence_UCB = min(max(influence_UCB,0),1);

% initialize marginal gain
MG = zeros(n,2);
for k = 1:K
    
    if k == 1
        
        MG = [(1:n)' sum(influence_UCB,2)];
        MG = sortrows(MG,2);
        
    else
        
        %going in the order of marginal gains
        for i = 1:n-k
            
            % take top node
            selected_node = MG(end,1);

    	    % recompute the marginal gain		            
            MG(end,2) = sum(bsxfun(@max, influence_UCB(selected_node,:),temp),2) - prev_spread;
            
            % check if its still better than the second
            if MG(end,2) >= MG(end-1,2)
                
                % if yes, just select that node
                % fprintf('Number of evaluations = %d\n', i);
                prev_spread = MG(end,2) + prev_spread;
                break;
                
            else
                
                % if no, re-sort and then pick top
                val = MG(end,2);
                a = MG(:,2);
                b = MG(:,1);
                pos = binarySearch(a,n-1,val);
                a = [a(1:pos-1) ; val ; a(pos:end-1)];
                b = [b(1:pos-1) ; selected_node ; b(pos:end-1)];
                MG = [b a];
                
            end
            
        end
        
    end
    
    S(k) = MG(end,1);
    
    if k == 1
        temp = influence_UCB(S(1:k),:);
    else
        temp = max(influence_UCB(S(1:k),:));
    end
    
    % so that we don't select the same node again
    MG(end,2) = -1;
    MG = circshift(MG,1);
    
end

end
