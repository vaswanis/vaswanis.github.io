#define DEBUG 0
#define PLOT 0
#define LOG 0
