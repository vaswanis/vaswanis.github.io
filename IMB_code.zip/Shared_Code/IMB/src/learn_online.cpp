//#define HEAD_TRACE
#define HEAD_INFO

#define HEAD_INFO
//#define HEAD_TRACE
#include "sfmt/SFMT.h"
#include "head.h"
#include "memoryusage.h"
#include "graph.h"
#include "common.h"
#include <time.h>
#include <boost/algorithm/string.hpp>

vector<double> calculate_gradient(int node, map<int,int> activeNodes, vector<double> theta, int total_nodes, TimGraph & m)
{
	int neighbourhood_size = (theta).size();
	vector<int> currneighbours_successful;
	vector<int> currneighbours_unsuccessful;
	vector<double> gradient_theta;
	float eps = 1e-3;
	int num_successful = 0;
	int num_unsuccessful = 0;

	for(int i = 0 ; i < neighbourhood_size; i++)
	{
		currneighbours_successful.insert(currneighbours_successful.end(), 0);
		currneighbours_unsuccessful.insert(currneighbours_unsuccessful.end(), 0);
	}

	if( activeNodes[node] != -1)
	{
		//node is active
		//cout << "Node "  << node << " is active " << endl;
		for(int i = 0 ; i < neighbourhood_size; i++)
		{
			int neighbour = m.gT_inferred[node][i];
			if( activeNodes[neighbour] <= activeNodes[node] - 2 && activeNodes[neighbour] != -1 )
			{
				//neighbour didn't activate node
				currneighbours_unsuccessful[i] = 1;
				num_unsuccessful++;
			}
			else if( activeNodes[neighbour] == activeNodes[node] - 1 )
			{
				//neighbour activated node
				currneighbours_successful[i] = 1;
				num_successful++;
			}

		}		
	
	}
	
	else
	{
		//node is inactive
		//cout << "Node "  << node << " is not active " << endl;
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			int neighbour = m.gT_inferred[node][i];
			if( activeNodes[neighbour] != -1)
			{
				currneighbours_unsuccessful[i] = 1;
			}
		}
	}

	
	float currthetavalue = 0;

	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_theta.insert( gradient_theta.end(), currneighbours_unsuccessful[i] );
		currthetavalue = currthetavalue + ( theta[i] * currneighbours_successful[i] );
	}
	
	
	if( activeNodes[node] != -1 && activeNodes[node] != 0)
	{
		if(currthetavalue != 0)
		{
			long double temp = ( ( exp(currthetavalue) - 1 ) );
			if( temp > 1e-8)
			{
				for( int i = 0 ; i < neighbourhood_size ; i++)
				{
					gradient_theta[i] = gradient_theta[i] - ((1 / (exp(currthetavalue) - 1)) * currneighbours_successful[i]);
				}
			}
		}
		else
		{
			for( int i = 0 ; i < neighbourhood_size ; i++)
			{
				gradient_theta[i] = gradient_theta[i] - (eps * currneighbours_successful[i]);
			}
		}		
	} 	

#if DEBUG
	cout << "gradient theta is " << endl;
	for( int i = 0 ; i < neighbourhood_size ; i++)
	{
		cout << gradient_theta[i] << endl; 
	}
#endif


	return gradient_theta;

}


vector<double> run(int node, map<int,int> activeNodes, vector<double> p, int total_nodes, TimGraph & m)
{
vector<double> theta;
vector<double> new_p;
vector<double> gradient_theta;
int neighbourhood_size = p.size();

int iterations = 1;
float alpha = 1e-1;
float optTol = 0.05;
float g_inf_norm = -1;

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	theta.insert( theta.end(),  -1 * log(1 - p[i]) );
	gradient_theta.insert(gradient_theta.end(), 0);
}

for(int iter = 0 ; iter < iterations ; iter ++)
{
	gradient_theta = calculate_gradient(node, activeNodes, theta, total_nodes, m);
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		theta[i] = theta[i] - ( alpha * gradient_theta[i] ) ;
		if(theta[i] < 0)
		{
			theta[i] = 0;
		}

		if( gradient_theta[i] > g_inf_norm )
		{
			g_inf_norm = gradient_theta[i];
		}

	}

	if( g_inf_norm < optTol )
	{
		//break;
	}

}

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	new_p.insert(new_p.end(), 1 - exp(-1 * theta[i]));
}

return new_p;

}


void parseArg(int argn, char ** argv)
{
	string dataset="";
	string model="";
	int k=0;
	int total_rounds = 0;
	
	string options_filename = argv[1];
	string line;
	std::vector<std::string> strs;
	std::vector<std::string> strs1;

	ifstream options_file(options_filename);
	if(options_file.is_open())
	{

		while(!options_file.eof())
		{
			getline(options_file,line);
			boost::split(strs, line, boost::is_any_of(" "));

			if(strs[0] == string("k")) k = atoi(strs[1].c_str());

			if(strs[0] == string("dataset")) dataset = strs[1].c_str();
			
			if(strs[0] == string("model")) {

				if(strs[1]==string("LT"))
				{
					model = strs[1].c_str();
				}
				else if(strs[1]==string("IC"))
				{
					model = strs[1].c_str(); ;
				}
				else
					ExitMessage("model should be IC or LT");
			}
	
			if(strs[0] == string("rounds")) total_rounds = atoi(strs[1].c_str()); 

		}

	}

	#if DEBUG

		cout << k << endl;
		cout << dataset << endl;
		cout << epsilon << endl;
		cout << model << endl;
		cout << total_rounds << endl;
		cout << T << endl;
		cout << mode << endl;
		cout << no_test_cascades << endl;
		cout << allowed_prob_threshold << endl;
			
	#endif

	if (dataset=="")
		ExitMessage("option dataset not specified");
	if (k==0)
		ExitMessage("option k not specified");
	if (model=="")
		ExitMessage("option model not specified");
	if (total_rounds == 0)
		ExitMessage("option total rounds  not specified");
			
	string graph_file;
	dataset = dataset + "/";
	if(model=="IC")
		graph_file=dataset + "graph_ic.inf";
	else if(model=="LT")
		graph_file=dataset + "graph_lt.inf";
	
	map<string, float> parameters;

	//Non adaptive IM schemes
	TimGraph NA_known_m(dataset, graph_file, parameters);
	TimGraph NA_bandit_m(dataset, graph_file, parameters);

	string cascades_filename = "NA_bandit_spread.txt";
	ifstream cascades_file(cascades_filename);
	
	map <int, int > activeNodes;
	int node;
	int timestamp;
	set<int> active;
	set<int> check_nodes;
	float true_L2 = 0;
	// ---------------------------------------------------------------------------------------------------------------------------------  //
	for(int round = 0 ; round < total_rounds ; round++)
	{

		activeNodes.clear();
		check_nodes.clear();
		active.clear();
		for(int i = 0 ; i < NA_known_m.n  ; i++)
		{
			activeNodes[i] = -1;
		}

		while ( getline(cascades_file,line) )
		{
			if( line[0] == '-' )
			{
				break;
			}
			else
			{
				boost::split(strs, line, boost::is_any_of(","));
				node = atoi(strs[0].c_str());
				timestamp = atoi(strs[1].c_str());
				activeNodes[node] = timestamp;
				active.insert(node);
				check_nodes.insert(node);
			}
		}

		cout << "Number of active nodes = " << active.size() << endl;

		for( set<int>::iterator it = active.begin() ; it != active.end() ; ++it) 
		{  
			node = *it;
			for(int j = 0; j < (int)NA_known_m.gT_true_static[node].size(); j++)
			{
				check_nodes.insert(NA_known_m.gT_true_static[node][j]);	
			}
		}

		//cout << check_nodes.size() << endl;

		for( set<int>::iterator it = check_nodes.begin() ; it != check_nodes.end() ; ++it) 
		{
			node = *it;
			//cout << "Solving for node " << node << endl;
			//cout << "Neighbourhood size = " << NA_bandit_m.probT_learnt_reverse[node].size() << endl;
			NA_bandit_m.probT_learnt_reverse[node] = run(node, activeNodes, NA_bandit_m.probT_learnt_reverse[node], NA_bandit_m.n, NA_bandit_m);		
		}


			NA_bandit_m.probT_inferred = NA_bandit_m.probT_learnt_reverse;

		//calculate error in the estimation of probabilities for the bandit setting		
		float NA_l2_err = 0;


		for(int j = 0; j < NA_known_m.n ; j++)
		{
			for(unsigned int i =  0 ; i < NA_known_m.probT_inferred[j].size() ; i++) 
			{

					NA_l2_err = NA_l2_err + pow((NA_known_m.probT_inferred[j][i] - NA_bandit_m.probT_inferred[j][i]),2);
					true_L2 = true_L2 + pow( NA_known_m.probT_inferred[j][i] , 2);

			}
		}

			cout << "Non Adaptive L2 Error:" << sqrt(NA_l2_err / true_L2) << endl;

	}

	cascades_file.close();

}

int main(int argn, char ** argv)
{
	OutputInfo info(argn, argv);
	parseArg( argn, argv );
	return 0;
}
