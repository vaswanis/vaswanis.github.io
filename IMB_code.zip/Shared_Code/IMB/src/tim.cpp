//#define HEAD_TRACE
#define HEAD_INFO

#define HEAD_INFO

//#define BOOST_MATH_DISABLE_FLOAT128 
//#define HEAD_TRACE
#include <boost/algorithm/string.hpp>
#include "sfmt/SFMT.h"
#include "head.h"
#include "memoryusage.h"
#include "graph.h"
#include "common.h"
#include <time.h>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>

int total_spread = 0;

//function to write final learnt prob values 
int write_to_file(TimGraph m)
{
	string T_filename;
	string X_filename;
	string P_filename;

	P_filename = "final_probT_learnt_vals.txt";   

	ofstream probT_learnt_file(P_filename.c_str(), ios::app);	    

	for(int j = 0; j < m.n ; j++)
	{
		for(unsigned int i =  0 ; i < m.probT_learnt_reverse[j].size() ; i++) {

			probT_learnt_file << m.probT_learnt_reverse[j][i] << " ";
		}
		probT_learnt_file << endl;
	}

	probT_learnt_file.close();

	return 0;
}

int run( TimGraph & m, string dataset, map<string,float> parameters, int is_bandit, int round, int is_exploit )
{

#if DEBUG
	cout << "dataset:" << dataset << " k:" << parameters["k"] << " epsilon:"<< parameters["epsilon"] <<   " model:" << model << endl;
#endif

	
	if ( parameters["spread_computation_model"] == 1 ) 
	{
		m.setInfuModel(InfGraph::IC);
	}
	else if( parameters["spread_computation_model"] == 2 )
	{
		m.setInfuModel(InfGraph::LT);
	}
	else
	{
		cout << "Spread computation model is incorrectly specifiied" << endl;
		return -1;
	}	
	

#if DEBUG 
	cout<<"Finish Read Graph, Start Influence Maximization"<<endl;
#endif

	//estimates OPT, generates the RR sets and finds the optimal seed set
	int spread = m.EstimateOPT(parameters, is_bandit , round , is_exploit);

#if DEBUG
	cout<<"Selected k SeedSet: ";
	for(auto item:m.seedSet)
		cout<< item << " ";
	cout<<endl;
#endif 

	return spread;

}

float estimate_spread(TimGraph m, map<string, float> parameters,  vector<int> inactive, set<int> seeds)
{

	float ept;
	float ep_step2;
	float ep_step3;
	float spread;

	float epsilon = parameters["epsilon"];
	int k = m.k;

	ep_step2=ep_step3=epsilon;
	ep_step2=5*pow(sqr(ep_step3)/k, 1.0/3.0);
	ept= m.EstimateEPT(k,inactive);
	m.BuildSeedSet(k);

	//get KPT+ (ept) from KPT (ept)
	m.BuildHyperGraph2(ep_step2, ept,inactive);
	ept = m.InfluenceHyperGraph();
	ept/=1+ep_step2;

	//estimates the number of RR sets required and generates them
	m.BuildHyperGraph3(ep_step3, ept,k,inactive);
	m.seedSet.clear();

	m.seedSet = seeds;
	spread = m.InfluenceHyperGraph();  

	return spread;

}

void parseArg(int argn, char ** argv)
{
	string dataset;

	int diffusion_model = 0;
	int spread_computation_model = 0;

	double epsilon = 0;
	int k=0;
	int total_rounds = 0;
	int T = 0;
	float initial_eta = 0;
	float gamma = 0;
	float fraction_exploration_rounds = -1;
	int no_test_cascades = -1;
	float allowed_prob_threshold = -1;
	int learning_procedure = -1;
	int use_prior = -1;
	int prior_alpha = -1;
	int prior_beta = -1;
	int UCB_pmax = -1;
	int bandit_mode = -1;
	
	string options_filename = argv[1];
	string line;
	std::vector<std::string> strs;
	std::vector<std::string> strs1;

	ifstream options_file(options_filename);

	if(options_file.is_open())
	{

		while(!options_file.eof())
		{
			getline(options_file,line);
			boost::split(strs, line, boost::is_any_of(" "));

			if(strs[0] == string("k")) k = atoi(strs[1].c_str());

			if(strs[0] == string("dataset")) dataset = strs[1].c_str();

			if(strs[0] == string("diffusion_model")) diffusion_model = atoi(strs[1].c_str());

			if(strs[0] == string("spread_computation_model")) spread_computation_model = atoi(strs[1].c_str());
			
			if(strs[0]==string("epsilon")) epsilon = atof(strs[1].c_str());

			if(strs[0] == string("rounds")) total_rounds = atoi(strs[1].c_str()); 

			if(strs[0] == string("horizon")) T = atoi(strs[1].c_str()); 

			if(strs[0] == string("initial_eta")) initial_eta = atof(strs[1].c_str()); 	

			if(strs[0] == string("gamma")) gamma = atof(strs[1].c_str()); 	

			if(strs[0] == string("bandit_mode")) 
			{	
				bandit_mode = atoi(strs[1].c_str()); 
			}

			if(strs[0] == string("fraction_exploration_rounds")) fraction_exploration_rounds = atof(strs[1].c_str()); 	

			if(strs[0] == string("no_test_cascades")) no_test_cascades = atoi(strs[1].c_str()); 
	
			if(strs[0] == string("allowed_prob_threshold")) allowed_prob_threshold = atof(strs[1].c_str()); 

			if(strs[0] == string("learning_procedure"))  learning_procedure = atoi(strs[1].c_str()); 
			if(strs[0] == string("use_prior"))  use_prior = atoi(strs[1].c_str()); 
			if(strs[0] == string("prior_alpha"))  prior_alpha  = atoi(strs[1].c_str()); 
			if(strs[0] == string("prior_beta"))  prior_beta = atoi(strs[1].c_str()); 
			if(strs[0] == string("UCB_pmax")) UCB_pmax = atof(strs[1].c_str()); 


		}

	}

	#if DEBUG
		cout << diffusion_model << endl;		
		cout << spread_computation_model << endl;		
	
		cout << k << endl;
		cout << dataset << endl;
		cout << epsilon << endl;
		cout << total_rounds << endl;
		cout << T << endl;
		cout << initial_eta << endl;
		cout << gamma << endl;

		cout << bandit_mode << endl;

		cout << fraction_exploration_rounds << endl;
		cout << no_test_cascades << endl;
		cout << allowed_prob_threshold << endl;

		cout << learning_procedure << endl;
		cout << use_prior << endl;
		cout << prior_alpha << endl;
		cout << prior_beta << endl;

		cout << UCB_pmax << endl;

	#endif

	if (dataset=="./")
		ExitMessage("option dataset not specified");
	if (k==0)
		ExitMessage("option k not specified");
	if (diffusion_model == 0)
		ExitMessage("option diffusion_model not specified");
	if (spread_computation_model == 0 )
		ExitMessage("option spread_computation_model not specified");
	if (epsilon==0)

	if (k==0)
		ExitMessage("option k not specified");
	if (epsilon==0)
		ExitMessage("option epsilon not specified");
	if (total_rounds == 0)
		ExitMessage("option total rounds  not specified");
	if (T == 0)
		ExitMessage("option horizon not specified");
	if (initial_eta == 0)
		ExitMessage("option initial_eta not specified");
	if (gamma == 0)
		ExitMessage("option gamma not specified");

	if (bandit_mode == 0)
		ExitMessage("option bandit_mode not specified");

	if (fraction_exploration_rounds == -1)

	if (fraction_exploration_rounds == -1)
		ExitMessage("option fraction_exploration_rounds not specified");
	if (no_test_cascades == -1)
		ExitMessage("option no_test_cascades not specified");
	if (allowed_prob_threshold == -1)
		ExitMessage("option allowed_prob_threshold not specified");
	if (learning_procedure == -1)
		ExitMessage("option learning_procedure not specified");
	if (use_prior == -1)
		ExitMessage("option use_prior not specified");
	if( use_prior == 1)
	{
		if (prior_alpha == -1)
			ExitMessage("option prior_alpha not specified");
		if (prior_beta == -1)
			ExitMessage("option prior_beta not specified");
	}

	if ( UCB_pmax == -1 )
		ExitMessage("option UCB_pmax not specified");
		
	string graph_file;
	graph_file= "./graph_ic.inf";

	//pack all the parameters to pass to run
	map<string, float> parameters;
	parameters["diffusion_model"] = diffusion_model;
	parameters["spread_computation_model"] = spread_computation_model;

	parameters["k"] = k;
	parameters["epsilon"] = epsilon;
	parameters["horizon"] = T;
	
	parameters["initial_eta"] = initial_eta;

	parameters["bandit_mode"] = bandit_mode;
	parameters["learning_procedure"]  = learning_procedure;
	
	parameters["use_prior"] = use_prior;
	parameters["prior_alpha"] = prior_alpha;
	parameters["prior_beta"] = prior_beta;

	parameters["UCB_pmax"] = UCB_pmax;

	if( use_prior == 1)
	{
		parameters["pinit"] = 2 *  (float)(prior_alpha) / (prior_alpha + prior_beta);
	}
	else
	{
		parameters["pinit"] = 1e-6;
	}

	//Non adaptive IM schemes
	parameters["spread_computation_model"] = 1;
	TimGraph IC_bandit_m("./", graph_file, parameters);

	parameters["spread_computation_model"] = 2;
	TimGraph LT_bandit_m("./", graph_file, parameters);

	// ---------------------------------------------------------------------------------------------------------------------------------  //
	float IC_bandit_spread = 0;
	float LT_bandit_spread = 0;
	double IC_time_per_round = 0;
	double LT_time_per_round = 0;

	//average spread for the conventional IM process
	float epsilon_t = 0;
	int exploration_rounds = 0;

	if( bandit_mode == 5)
	{
		exploration_rounds = (int)(fraction_exploration_rounds * total_rounds);
	}

	IC_bandit_m.probT_inferred = IC_bandit_m.probT_learnt_reverse; //the inferred probabilities for the NA bandit are learnt by playing the bandit game
	LT_bandit_m.probT_inferred = LT_bandit_m.probT_learnt_reverse; //the inferred probabilities for the NA bandit are learnt by playing the bandit game

	//for hybrid
	int org_bandit_mode = bandit_mode;

	string fname;
	fname = "./Results/" + dataset;
	fname.erase(fname.size() - 1);
	fname = fname + "_" +  to_string(k) + "_" + to_string(total_rounds) + "_cascades.txt";
	FILE * f = fopen(fname.c_str(),"w+");

	//for timing 
	clock_t t_start,t_end;

	for(int round = 0 ; round < total_rounds ; round++)
	{

		//for hybrid
		if( org_bandit_mode == 8)
		{
			if( round > 250  )
			{
				bandit_mode = 4;
				parameters["bandit_mode"] = bandit_mode;
			}	

			else
			{
				bandit_mode = 7;
				parameters["bandit_mode"] = bandit_mode;
			}
		}

		if( bandit_mode == 1)
		{
			epsilon_t = min( (gamma / (round+1)) , (float)(1.0));
		}

		float toss = ((float)(rand() % 1001))/(float)1000;
		int is_exploit;
		if( (bandit_mode > 5) || (bandit_mode == -1) || (toss < epsilon_t && bandit_mode == 1) || (round < exploration_rounds && bandit_mode == 5) )
		{

			is_exploit = 0;
		}
		else
		{
			is_exploit = 1;
		}

		if(diffusion_model == 1)
		{ 
	
			//creating a true possible world according to the IC model
			for(int i = 0 ; i < IC_bandit_m.n ; i++)
			{  
				for(int j = 0; j < (int)IC_bandit_m.gT_true_static[i].size(); j++)
				{

					float toss = ((float)(rand() % 1001))/(float)1000;
					if(toss < IC_bandit_m.probT_true_static[i][j])
					{
						IC_bandit_m.probT_true[i][j] = 1;
						LT_bandit_m.probT_true[i][j] = 1;

						//save these edges to a file - storing the cascade to a file 
						fprintf(f,"%d,%d,",i, IC_bandit_m.gT_true_static[i][j]);
					}

					else
					{
						//make false edge - giving same feedback to both models 
						IC_bandit_m.probT_true[i][j] = 0;
						LT_bandit_m.probT_true[i][j] = 0;
					}

				}
			}
		}


		else if(diffusion_model == 2)
		{
			int i,j; 

			// zero out all edges initially
			for(i = 0 ; i < LT_bandit_m.n ; i++)
			{  
				for(j = 0; j < (int)LT_bandit_m.gT_true_static[i].size(); j++)
				{

						IC_bandit_m.probT_true[i][j] = 0;
						LT_bandit_m.probT_true[i][j] = 0;
				}
			}


			//creating a true possible world according to the LT model - todo
			for(i = 0 ; i < LT_bandit_m.n ; i++)
			{
				float toss = ((float)(rand() % 1001))/(float)1000;
				for(j = 0; j < (int)LT_bandit_m.gT[i].size(); j++)
				{
					toss = toss - LT_bandit_m.probT[i][j];
				
					if(toss <= 0)
					{
						break;	
					}			
		
				}
			  
			        if( j <= (int)LT_bandit_m.gT[i].size() - 1 )
				{
					// chose the node LT_bandit_m.gT[i][j] as the incoming neighbour
					int incoming_neighbour = LT_bandit_m.gT[i][j];

					// write to file - edge from a -> b
					fprintf(f,"%d,%d,",LT_bandit_m.gT[i][j],i);

					// convert to probT_true 
					// checking all the outgoing edges from incoming neeighbour and find the one which points to i
					vector<int>::iterator it = find( (LT_bandit_m.gT_true_static[incoming_neighbour]).begin(), (LT_bandit_m.gT_true_static[incoming_neighbour]).end(), i );

					// find the corresponding index
					int index = it - (LT_bandit_m.gT_true_static[incoming_neighbour]).begin();
					
					IC_bandit_m.probT_true[incoming_neighbour][index] = 1;
					LT_bandit_m.probT_true[incoming_neighbour][index] = 1;

				}
				else
				{
					; // chose no incoming neighbour				
				}

			}
		}

		else
		{
		
			cout << "Diffusion model is incorrectly specified" << endl;	
		}

		fprintf(f, "\n");

		// IM in bandit setting
		// assuming IC model
		if( spread_computation_model == 1 || spread_computation_model == 3)
		{
			parameters["spread_computation_model"] = 1;

			t_start = clock();		
			IC_bandit_spread = run(IC_bandit_m, dataset, parameters, 1, round, is_exploit);
			t_end = clock();
			
			IC_time_per_round = IC_time_per_round + ((double)(t_end - t_start) / CLOCKS_PER_SEC);
			IC_bandit_m.probT_inferred = IC_bandit_m.probT_learnt_reverse; //the inferred probabilities for the NA bandit are learnt by playing the bandit game
		}

		// assuming LT model
		if( spread_computation_model == 2 || spread_computation_model == 3)
		{
			parameters["spread_computation_model"] = 2;

			t_start = clock();		
			LT_bandit_spread = run(LT_bandit_m, dataset, parameters, 1, round, is_exploit);
			t_end = clock();
			
			LT_time_per_round = LT_time_per_round + ((double)(t_end - t_start) / CLOCKS_PER_SEC);
			LT_bandit_m.probT_inferred = LT_bandit_m.probT_learnt_reverse; //the inferred probabilities for the NA bandit are learnt by playing the bandit game
		}


		// writing to file 
		if(  spread_computation_model == 3)	
		{
			cout << round+1 << "," << IC_bandit_spread << "," << LT_bandit_spread << endl;
		}
		else if( spread_computation_model == 2)
		{
			cout << round+1 << "," << LT_bandit_spread << endl;
		}
		else if( spread_computation_model == 1)
		{
			cout << round+1 << "," << IC_bandit_spread << endl;
		}

	} // end of t = 1:T loop

	
	if( spread_computation_model == 1 || spread_computation_model == 3)
	{
  		IC_time_per_round = IC_time_per_round / (total_rounds);
	}
	
	if( spread_computation_model == 2 || spread_computation_model == 3)
	{
  		LT_time_per_round = LT_time_per_round / (total_rounds);
	}

	// writing to file 
	if(  spread_computation_model == 3)	
	{
		cout << -1 << "," << IC_time_per_round << "," << LT_time_per_round <<endl;
	}
	else if( spread_computation_model == 2)
	{
		cout << -1 << "," << LT_time_per_round <<endl;
	}
	else if( spread_computation_model == 1)
	{
		cout << -1 << "," << IC_time_per_round <<endl;
	}

	fclose(f);
}

int main(int argn, char ** argv)
{
	srand(time(NULL));
	OutputInfo info(argn, argv);
	parseArg( argn, argv );
	return 0;
}

