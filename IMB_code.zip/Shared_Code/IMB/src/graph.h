#define HEAD_INFO
#include "sfmt/SFMT.h"
#include "common.h"

//comments:
// hasnode - boolean vector with true entries for 
// gT - adjacency list for each node;  gT[b] - gives the nodes with edges into b
// probT - gives influence probs;  probT[b] - gives the probs for the edges into b
// inDeg - in degree for each node
// outDeg - out degree for each node

using namespace std;

typedef double (*pf)(int,int); 
class Graph
{

	public:
		int n, m, k;
		vector<int> inDeg;
		vector<int> outDeg;
		vector<int> outDeg_idx;
		vector<vector<int>> gT;
		vector<vector<int>> gT_inferred;
		vector<vector<int>> gT_true;
		vector<vector<int>> gT_true_static;

		vector<vector<double>> probT;
		vector<vector<double>> probT_inferred;
		vector<vector<double>> probT_true;
		vector<vector<double>> probT_true_static;

		//probabilities learnt by playing the bandit game
		vector<vector<double>> probT_learnt;
		vector<vector<double>> probT_learnt_reverse;

		//for adagrad implementation
		vector<vector<double>> grad_norm; 

		//adding variables for book-marking number of times an arm has been activated
		vector<vector<int>> Xi;
		vector<vector<int>> Ti;
		vector<int> visited_node;
		vector<double> reward;

		//book-keeping for ERM
		map<int, map<int,int> > cascades;
		set<int> global_check_nodes;
		map<int, set<int> > cascades_involved;		

		vector<int> num_active ; 

		vector<bool> visit;
		vector<int> visit_mark;
		enum InfluModel {IC, LT};
		InfluModel influModel;

		void setInfuModel(InfluModel p){
			influModel=p;
		}

		string folder;
		string graph_file;

		float num_clashes = 0;

		void readNM(){
			ifstream cin((folder+"attribute.txt").c_str());
			ASSERT(!cin == false);
			string s;
			while(cin >> s){
				if(s.substr(0,2)=="n="){
					n=atoi(s.substr(2).c_str());
					continue;
				}
				if(s.substr(0,2)=="m="){
					m=atoi(s.substr(2).c_str());
					continue;
				}
				ASSERT(false);
			}
			visit_mark=vector<int>(n);
			visit=vector<bool>(n);
			cin.close();
		}

		void add_edge(int a, int b, double p, map<string,float> parameters){

			//maintains list of edges going in
			probT[b].push_back(p);
			probT_inferred[b].push_back(p);

			//maintains list of edges going out
			probT_true[a].push_back(p);
			probT_true_static[a].push_back(p);

			//maintains list of in-neighbours
			gT[b].push_back(a);
			gT_inferred[b].push_back(a);

			//maintains list of out-neighbours
			gT_true[a].push_back(b);
			gT_true_static[a].push_back(b);

			//creating Xi,Ti for m arms -  corresponding to the m edges
			Xi[a].push_back(0);
			Ti[a].push_back(1e-3);

			float arb = ((float)(rand() % 1000) / 1001) * parameters["pinit"];
			probT_learnt[a].push_back(arb);
			probT_learnt_reverse[b].push_back(arb);
		
			//probT_learnt[a].push_back(1);
			//probT_learnt_reverse[b].push_back(1);
		
			//for implementing adagrad
			grad_norm[b].push_back(0);

			inDeg[b]++;
			outDeg[a]++;
		}

		vector<bool> hasnode;
		void readGraph( map<string,float> parameters ){
			FILE * fin= fopen((graph_file).c_str(), "r");
			ASSERT(fin != false);
			int readCnt=0;
			for(int i=0; i<m; i++){
				readCnt ++;
				int a, b;
				double p;
				int c=fscanf(fin, "%d%d%lf", &a, &b, &p);
				ASSERT(c==3);
				ASSERTT(c==3, a, b, p, c);
				ASSERT( a<n );
				ASSERT( b<n );
				hasnode[a]=true;
				hasnode[b]=true;
				add_edge(a, b, p, parameters);
			}
			if(readCnt !=m)
				ExitMessage("m not equal to the number of edges in file "+graph_file);


			fclose(fin);
		}

		Graph( string folder, string graph_file, map<string,float> parameters ):folder(folder), graph_file(graph_file) {

			if( parameters["spread_computation_model"] == 1)
			{
				InfluModel x = IC;
				setInfuModel(x);
			}
			else if( parameters["spread_computation_model"] == 2)
			{
				InfluModel x = LT;
				setInfuModel(x);
			}

			readNM();

			//init vector
			FOR(i, n){

				//initilizes empty adjacency lists for each of the 'n' nodes
				gT.push_back(vector<int>());
				gT_inferred.push_back(vector<int>());
				gT_true.push_back(vector<int>());
				gT_true_static.push_back(vector<int>());

				hasnode.push_back(false);

				probT.push_back(vector<double>());
				probT_inferred.push_back(vector<double>());
				probT_true.push_back(vector<double>());
				probT_true_static.push_back(vector<double>());

				Xi.push_back(vector<int>());
				Ti.push_back(vector<int>());
				probT_learnt.push_back(vector<double>());

				probT_learnt_reverse.push_back(vector<double>());
				grad_norm.push_back(vector<double>());

				//hyperGT.push_back(vector<int>());
				inDeg.push_back(0);
				outDeg.push_back(0);
				outDeg_idx.push_back(i);

				visited_node.push_back(0);
				reward.push_back(1.0);

				num_active.push_back(0);

			}

			readGraph(parameters);

			//std::sort( outDeg_idx.begin(), outDeg_idx.end(), myfunction );

#if DEBUG
			cout << "Graph read" << endl;
#endif

		}

};

double sqr(double t)
{
	return t*t;
}

#include "infgraph.h"
#include "timgraph.h"


