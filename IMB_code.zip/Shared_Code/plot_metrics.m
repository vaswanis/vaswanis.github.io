function [] =  plot_metrics(regret,fname,flag,compare_CUCB,spread_computation_model)

T = size(regret, 1);
figure();

if compare_CUCB == 1

	% assuming both IC, LT 
	options.markerSpacing = [T/5 1
	    T/5 1
	    ];
	options.xlabel = 'Number of rounds';
	options.legendLoc = 'Best';

	options.legend = {'DiLinUCB','CUCB'};

	options.colors = [1 0 0
	    0 1 0
	    ];
	options.lineStyles = {':','--'};

else

	options.markerSpacing = [T/5 1
	    ];
	options.xlabel = 'Number of rounds';
	options.legendLoc = 'Best';
	options.legend = {'DiLinUCB'};
	options.colors = [1 0 0
	    ];
	options.lineStyles = {':'};
end

if flag == 1
    options.ylabel = 'Cumulative Regret';
elseif flag == 2
    options.ylabel = 'Average Regret';
elseif flag == 3
    options.ylabel = 'Per-step Reward';
end

T_start = 1;
prettyPlot(T_start:T,regret(T_start:T,:)',options);
saveas(gcf,fname);
close all;

end
