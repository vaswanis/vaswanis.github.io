function [b,freq,inv_cov,cov_det] = update(draw,S,psi,b,freq,inv_cov,prev_cov_det)

K = size(S,1);
n = size(draw,1);
d = size(psi,1);

cov_det = prev_cov_det;

for j = 1:K
    
    %check reachability from source node
    s = S(j);
    [ob,~,~] = bfs(draw,s);
    
    y = (ob ~= -1);
    
    % update b
    b((s-1)*d+1: s * d) = b((s-1)*d+1: s * d) +  psi * y;
    
    % update frequency
    freq(s) = freq(s) + 1;
    
    t = inv_cov( s,s );
    
    %storing the determinant of the gram matrix at round t
    cov_det = cov_det + log(1 + t);
    
    % update inverse covariance matrix
    inv_cov = inv_cov - (inv_cov(:,s) * inv_cov(s,:))/ (1 + t);
    
end

end

