I wrote the function prettyPlot.m as a wrapper to some of the functionality in Matlab's plot function, in order to more quickly produce publication-quality figures.

To run the demos, type:
>> example_prettyPlot % Produces regularPlot.pdf prettyPlot.pdf
>> example_prettyPlot2 % Produces prettyPlot2.pdf
>> example_prettyPlot3 % Produces prettyPlot3.pdf
>> example_prettyPlot4 % Produces prettyPlot4.pdf

The documentation for prettyPlot only consists of this file, the default options (which can be optained by running prettyPlot with no arguments), the three demos above, and 'help prettyPlot'. However, I can be e-mailed for more details.

