A = dlmread('unweighted_node_10.inf');
n = 347;
d = 10;
psi = zeros(d,n);
for i = 2:size(A,1)
	psi( :, A(i,1) ) = A(i,2:end);
end
save('./features-10.mat','psi');
