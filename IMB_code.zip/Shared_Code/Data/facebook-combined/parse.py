import os
import sys

f = open('graph_ic.inf')
s = f.readlines()
f.close()

g = open('graph_ic.inf','w')

node_number = 0
dict = {}
edges = 0

for i in range(1,len(s)):

	t = s[i]
	l = t.split(' ')

	u = int(l[0])
	v = int(l[1])

	#get new node number for u
	if u in dict:
		u1 = dict[u]
	else:
		u1 = node_number
		dict[u] = node_number
		node_number = node_number + 1

	#get new node number for v
	if v in dict:
		v1 = dict[v]
	else:
		v1 = node_number
		dict[v] = node_number
		node_number = node_number + 1

	out_s = str(u1) + ' ' + str(v1) + '\n'
	g.write(out_s)
	edges = edges + 1

g.close()
print node_number, edges

#create attribute.txt
g = open('attribute.txt','w')
s = 'n=' + str(node_number) + '\n'
g.write(s)
s = 'm=' + str(edges) + '\n'
g.write(s)
g.close()
