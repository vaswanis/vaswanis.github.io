function [alpha] = estimate(inv_cov,b,n,d)

alpha = reshape(b,[d n]) * inv_cov';

end
