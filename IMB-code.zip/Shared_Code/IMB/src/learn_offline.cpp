//#define HEAD_TRACE
#define HEAD_INFO

#define HEAD_INFO
//#define HEAD_TRACE
#include "sfmt/SFMT.h"
#include "head.h"
#include "memoryusage.h"
#include "graph.h"
#include "common.h"
#include <time.h>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

double calculate_likelihood( int node, set<int> Ac, set<int> Bc, vector<double> p)
{

	double B = 1;
	double A = 1;
	set<int>::iterator iter;
	double LL = 1;
	
	for( iter = Bc.begin() ; iter != Bc.end() ; ++iter )
	{
		int neighbour_index = *iter;;
		B = B * ( 1 - p[neighbour_index] );
	}
	if( Bc.size() != 0)
		B = 1 - B;

	for( iter = Ac.begin() ; iter != Ac.end() ; ++iter )
	{
		int neighbour_index = *iter;
		A = A * ( 1 - p[neighbour_index] ); 
	}

	LL = A * B; 
	//cout << "LL is " << LL << endl;
	return LL;
}


vector<double> calculate_gradient(int node, set<int> Ac, set<int> Bc, vector<double> p)
{

	int neighbourhood_size = (p).size();
	vector<double> gradient_p;
	double B = 1;
	set<int>::iterator iter;
	
	//initialize gradient to zero
	for(int i = 0 ; i < neighbourhood_size; i++)
	{
		gradient_p.insert(gradient_p.end(), 0);
	}

	for( iter = Bc.begin() ; iter != Bc.end() ; ++iter )
	{
		int neighbour_index = *iter;;
		B = B * ( 1 - p[neighbour_index] );
	}

	if( Bc.size() != 0)
		B = 1 - B;

	for( iter = Ac.begin() ; iter != Ac.end() ; ++iter )
	{
		int neighbour_index = *iter;
		gradient_p[neighbour_index] = 1 / ( 1 - p[neighbour_index] ); 
	}

	// second loop over neighbours in set B
	for( iter = Bc.begin() ; iter != Bc.end() ; ++iter )
	{
		int neighbour_index = *iter;
		// for nodes in set B
		gradient_p[neighbour_index] = ((B - 1) / B) / ( 1 - p[neighbour_index] );
	}

#if DEBUG
	cout << "gradient p is " << endl;
	for( int i = 0 ; i < neighbourhood_size ; i++)
	{
		cout << gradient_p[i] << endl; 
	}
#endif


	return gradient_p;

}

vector<double> solve(int node, vector<set<int> > Ac, vector<set<int> > Bc, vector<double> p )
{
vector<double> new_p;
vector<double> old_p;
vector<double> gradient_p;
vector<double> temp;
int neighbourhood_size = p.size();

int iterations = 500;
int max_bt_iter = 5;
float optTol = 1e-2;
float optGrad = 1e-2;
float alpha_decrement = 0.8;
float alpha = 1;

float org_alpha;
float diff;
int flag = 0;
int bt_flag = 0;
double LL = -1;
double old_LL = 0;
float g_l2_norm = 0;

cout << "Inside the solve function for node " << node << " with " << Ac.size() << " cascades "  << endl;

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	p[i] = ((rand() % 1001))/(float)1000;
	gradient_p.insert(gradient_p.end(), 0);
	temp.insert(temp.end(), 0 );
	old_p.insert( old_p.end(), p[i] );
}

//initialize likelihood
old_LL = 0;
for(int c = 0 ; c < (int)(Ac.size()) ; c++)
{
	old_LL = old_LL + calculate_likelihood(node,Ac[c],Bc[c],p);
}
cout << "Original Likelihood:  " << old_LL << endl;

//initialize step size
org_alpha = alpha;


for(int iter = 0 ; iter < iterations ; iter ++)
{
	//initalize gradient and its l2 norm
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_p[i] = 0;
	}
	g_l2_norm = 0;
	diff = 0;

	//calculate gradient
	for( int c = 0 ; c < (int)(Ac.size()) ; c++ )
	{
		temp = calculate_gradient(node, Ac[c], Bc[c], p);
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			gradient_p[i] = gradient_p[i] + temp[i];	
		}
	}

	//normalize gradient and calculate its l2 norm 
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_p[i] = gradient_p[i] / Ac.size();
		g_l2_norm = g_l2_norm + powf( gradient_p[i],2);
	}

	//check for termination
	g_l2_norm= sqrt(g_l2_norm);
	#if DEBUG
		cout << "Gradient norm = " << g_l2_norm << endl;
	#endif

	if( g_l2_norm < optGrad )
	{
		cout << "Converged in " << iter << " iterations "  << endl;
		flag = 1;
		break;
	}

	//setting up back tracking line search
	alpha = org_alpha;
	LL = -1;
	bt_flag = 0;

	//back tracking linesearch
	for( int bt = 0 ; bt < max_bt_iter ; bt++)
	{
		#if DEBUG
		cout << "Inside linesearch iter " << bt << endl;
		#endif

		//take gradient step
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			p[i] = old_p[i] - ( alpha * gradient_p[i] ) ;

			if(p[i] < 0)
			{
				p[i] = 0;
			}

			if( p[i] > 1 )
			{
				p[i] = 0.99;
			}
		}
	
		//calculate likelihood at new point
		LL = 0;
		for(int c = 0 ; c < (int)(Ac.size()) ; c++)
		{
			LL = LL + calculate_likelihood(node,Ac[c],Bc[c],p);
		}
		#if DEBUG
		cout << "LL in backtracking linesearch: " << LL << endl;
		#endif

		//backtracking
		if( LL >= old_LL )
		{
			//successful step
			bt_flag = 1;
			break;
		}
		
		//step size is too aggressive
		alpha = alpha * alpha_decrement;

	}

	cout << "Iter " << iter <<  ":Likelihood = " << LL << endl;

	//update current point if backtracking was successful
	if( bt_flag == 1)
	{
		for( int i = 0 ; i < neighbourhood_size ; i++)
		{
		diff = diff + pow( ( old_p[i] - p[i] ),2);
		old_p[i] = p[i];
		}
		old_LL = LL;
	
		diff = sqrt(diff);

		#if DEBUG
		cout << "Difference in parameter values = "  << diff << endl;
		#endif
	
		if( diff < optTol )
		{
			flag = 1;
			cout << "Converged in " << iter << " iterations "  << endl;
			break;
		}
	}
	else
	{
		cout << "Unsuccessful Backtracking line search" << endl;
		break;
	}

}

if( flag == 0)
{
	cout << "Reached max iterations" << endl;
}

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	//cout << "Learnt prob is " << p[i] << endl;
	new_p.insert(new_p.end(), old_p[i]);
}

return new_p;

}

void parseArg(int argn, char ** argv)
{
	string dataset="./datasets/";
	string cascades_filename = "";
	string nodes_filename = "";
	string write_filename = "graph_ic_learnt.inf";

	int total_rounds = 0;
	
	string options_filename = argv[1];
	string line;
	std::vector<std::string> strs;
	std::vector<std::string> strs1;

	ifstream options_file(options_filename);
	if(options_file.is_open())
	{
		while(!options_file.eof())
		{
			getline(options_file,line);
			boost::split(strs, line, boost::is_any_of(" "));

			if(strs[0] == string("dataset")) dataset = dataset + strs[1].c_str();

			if(strs[0] == string("cascades_filename")) cascades_filename = strs[1].c_str();

			if(strs[0] == string("total_rounds")) total_rounds = atoi(strs[1].c_str());
		}
	}

	map<string,float> parameters;
		
	#if DEBUG
		cout << dataset << endl;
		cout << cascades_filename << endl;
		cout << total_rounds << endl;
	#endif

	if (dataset=="./datasets/")
		ExitMessage("option dataset not specified");
	if (cascades_filename == "")
		ExitMessage("option cascades filename not specified");
	if (total_rounds == 0)
		ExitMessage("option total rounds  not specified");
			
	string graph_file;
	dataset = dataset + "/";
	graph_file = dataset + "graph_ic.inf";

	cascades_filename = dataset + cascades_filename;
	nodes_filename = dataset + "Nodes.txt";

	write_filename = dataset + write_filename;
	
	cout << graph_file << endl;
	cout << cascades_filename << endl;

	//Non adaptive IM schemes
	TimGraph NA_known_m(dataset, graph_file, parameters );

	ifstream cascades_file(cascades_filename);
	
	map <int, set<int> > cascades;
	map <int, set<int> > self_active_cascades;
	map <int, set<int> > active_cascades;
	int cascade_id;
	int node_id;
	set<int> active;
	int round = 0; 
	int total_nodes = 100000;

	// ---------------------------------------------------------------------------------------------------------------------------------  //
	for( round = 0 ; round < total_rounds ; round++ )
	{

		active.clear();

		getline(cascades_file,line);

		boost::split(strs, line, boost::is_any_of(":"));

		cascade_id = atoi( strs[0].c_str() );

		boost::split(strs1, strs[1], boost::is_any_of(","));
		
		for( int i = 0 ; i < (int)(strs1.size()) ; i++ )
		{
			active.insert( atoi( strs1[i].c_str() ) );
		}


		cascades[cascade_id] = active;

	}

	cascades_file.close();

	ifstream nodes_file(nodes_filename);
	ofstream write_file(write_filename);

	//initialize active cascades for each node
	active.clear();
	for( int i = 0 ; i < NA_known_m.n ; i++)
	{
		active_cascades[i] = active;
	}

	//get live cascades for each node
	for( int i = 0 ; i < 147335 ; i++)
	{

		active.clear();
		getline(nodes_file,line);

		boost::split(strs, line, boost::is_any_of(":"));

		node_id = atoi( strs[0].c_str() );

		boost::split(strs1, strs[1], boost::is_any_of(","));
		
		for( int i = 0 ; i < (int)(strs1.size()) ; i++ )
		{
			active.insert( atoi( strs1[i].c_str() ) );
		}


		self_active_cascades[node_id] = active;

	}
	
	nodes_file.close();


	//union over the active cascades of each incoming neighbour
//	for( int i = 0 ; i < NA_known_m.n ; i++ )
	for( int i = 0 ; i < total_nodes ; i++ )
	{
		node_id = i;
		active = self_active_cascades[node_id];

		for( unsigned int j = 0 ; j < NA_known_m.gT[node_id].size() ; j++)
		{
			int neighbour = NA_known_m.gT[node_id][j];
			
			active.insert(self_active_cascades[neighbour].begin(), self_active_cascades[neighbour].end());
		}

		active_cascades[node_id] = active;
		
		cout << "Size of active cascade set for node " << node_id << " = " << self_active_cascades[node_id].size() << endl;
		cout << "Size of the check cascade set for node " << node_id << " = "  << active_cascades[node_id].size() << endl; 
	}

	vector<set<int> > Ac; 
	vector<set<int> > Bc; 
	set<int> A;
	set<int> B;

	set <int>::iterator s_iter;
	set <int>::iterator iter;
	map <int,set<int> >::iterator m_iter;

	set <int> temp_active_cascade_set;
	set <int> temp_cascade;

	m_iter = (active_cascades).begin();

	int node_count = 0;

	//form sets A and B for each node v
	for( m_iter = (active_cascades).begin(); m_iter != (active_cascades).end() ; ++m_iter )
	{

		node_count++;
		if( (node_count-1) == total_nodes ) 
			break;

		//target node
		int v = m_iter->first;

		if( self_active_cascades[v].size() == 0 )
		{
			for( unsigned int i = 0 ; i < NA_known_m.gT[v].size() ; i++ )
			{
			string write_string = to_string(NA_known_m.gT[v][i]) + " " + to_string(v) + " " + to_string( NA_known_m.probT_learnt_reverse[v][i] ) +  "\n" ;
			write_file << write_string;
			}
	
			continue;
		}

		#if DEBUG
		cout << "Target node is " << v << endl;
		#endif

		//temp_active_cascade_set contains ids all the cascades i is involved in
		temp_active_cascade_set = m_iter->second;

		Ac.clear();
		Bc.clear();

		#if DEBUG
		cout << "Need to solve for " << temp_active_cascade_set.size() << " cascades" << endl;
		#endif

		for(  s_iter = temp_active_cascade_set.begin() ; s_iter != temp_active_cascade_set.end() ; ++s_iter )
		{
			
			A.clear();
			B.clear();

			//get cascade id
			cascade_id = *s_iter;
		
			//temp_cascade contains the nodes involved in cascade with id cascade_id
			temp_cascade = cascades[cascade_id];
	
			#if DEBUG
			cout << "Solving for cascade ID = " << cascade_id << " with " << temp_cascade.size() << " active nodes " << endl;
			#endif
		
			//check whether the target node v is active in temp_cascade
			iter = find (temp_cascade.begin(),temp_cascade.end (), v);
			if( iter != temp_cascade.end() )
			{				
				//v is active				
				//get index of i in the temp_cascade list

				#if DEBUG
				cout << "Target node is active in this cascade" << endl;
				#endif

				int v_index = std::distance(temp_cascade.begin(),iter);

				//add all neighbours u which are active before v
				for( unsigned int x = 0 ; x < NA_known_m.gT[v].size() ; x++ )
				{
					int neighbour = NA_known_m.gT[v][x];

					//check if u is active
					iter = find (temp_cascade.begin(),temp_cascade.end (), neighbour);

					if( iter != temp_cascade.end() )
					{
						//u is active
						int x_index = std::distance( temp_cascade.begin(), iter );
						
						#if DEBUG
						cout << "v_index = " << v_index << " ; x_index = " << x_index << endl;
						#endif
		
						//if( 1 )
						if( x_index < v_index )
						{
							//u got activated b3efore v => u is responsible for v's activation => add u to set B
							B.insert(x);
						}
					}
		
				}

			}	

			else
			{
				//v is inactive
				//if any neighbour is active, add it to set A

				#if DEBUG
				cout << "Target node is inactive in this cascade" << endl;
				#endif


				for( unsigned int x = 0 ; x < NA_known_m.gT[v].size() ; x++ )
				{
					int neighbour = NA_known_m.gT[v][x];

					//check if u is active
					iter = find (temp_cascade.begin(),temp_cascade.end (), neighbour);
					
					if( iter != temp_cascade.end() )
					{
						//u is active => activation attempt from u to v failed => add u to A
						A.insert(x);
					}

				}		

			}

			#if DEBUG
			cout << "Size of set A = " << A.size() << " ; Size of set B = " << B.size() << endl;
			#endif 
	
			if( A.size() + B.size() != 0 )
			{
				#if DEBUG
				cout << "Need to solve cascade " << cascade_id << " for target node " << v << endl;
				#endif

				Ac.push_back(A);	
				Bc.push_back(B);	
		
			}

			#if DEBUG
			if( B.size() != 0 )		
				cout <<  "Size of set B for Cascade " << cascade_id << " for target node "  << v << " = " << B.size() << endl;
			#endif

		}

		//learn for node i - given the sets A and B for each cascade in the vectors Ac, Bc
		NA_known_m.probT_learnt_reverse[v] = solve(v, Ac, Bc, NA_known_m.probT_learnt_reverse[v] );		
		
		for( unsigned int i = 0 ; i < NA_known_m.gT[v].size() ; i++ )
		{

			string write_string = to_string(NA_known_m.gT[v][i]) + " " +to_string(v) + " " + to_string( NA_known_m.probT_learnt_reverse[v][i] ) +  "\n" ;
			write_file << write_string;
		}
		
	}
	
}

int main(int argn, char ** argv)
{
	OutputInfo info(argn, argv);
	parseArg( argn, argv );
	return 0;
}
