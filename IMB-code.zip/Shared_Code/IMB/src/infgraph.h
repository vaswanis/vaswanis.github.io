//comments:
// hyperGT - stores information for each RR set - nodes involved in the RR set
// hyperG - stores RR set information for each nodes - number of RR sets a node occurs in 
#include "common.h"

class VV
{
	public:
		vector<int> head;
		vector<int> next;
		vector<int> data;
		vector<int> vsize;

		void clear()
		{
			head.clear();
			next.clear();
			data.clear();
			vsize.clear();
		}

		// trick for not change code
		void push_back(vector<int> x){
			ASSERT(x.size()==0);
			addVector();
		}

		void addVector()
		{
			head.push_back(-1);
			vsize.push_back(0);
		}

		int size(int t){
			return vsize[t];
		}

		//vv[a].push_back(b)
		void addElement( int a, int b)
		{
			//a.push_back(b);
			vsize[a]++;
			data.push_back(b);
			next.push_back(head[a]);
			head[a]=next.size()-1;

		}
		//loop
		//for(int t:vv[a])
		//for (int x=vv.head[a]; x!=-1; x=vv.next[x])
		//{
		//t=vv.data[x]
		//}
};


class InfGraph:public Graph
{
	public:
		vector<vector<int>> hyperG;
		vector<vector<int>> hyperGT;

		typedef set<int> UserList;

		InfGraph(string folder, string graph_file, map<string, float> parameters):Graph(folder, graph_file, parameters){

			hyperG.clear();

			for(int i=0; i<n; i++)
				hyperG.push_back(vector<int>());

			//seeding the random number generator
			for(int i=0; i<12; i++)
				sfmt_init_gen_rand(&sfmtSeed, i+1234);
		}

		enum ProbModel {TR, WC, TR001};
		ProbModel probModel;

		//function which generates R RR sets
		void BuildHypergraphR(int64 R, vector<int> inactive){
			hyperId=R;
			hyperG.clear();
			for(int i=0; i<n; i++)
				hyperG.push_back(vector<int>());
			hyperGT.clear();
			while((int)hyperGT.size() <= R)
				hyperGT.push_back( vector<int>() );

			//build RR set for randomly selected node
			for(int i=0; i<R; i++){

				int target_node = inactive[ (sfmt_genrand_uint32(&sfmtSeed) % inactive.size()) ] ;
				BuildHypergraphNode(target_node, i, true);

			}

			int totAddedElement=0;
	
			//iterates over the RR sets	
			for(int i=0; i<R; i++){

				//iterates over the nodes involved in each RR set
				for(int t:hyperGT[i])
				{
					hyperG[t].push_back(i);
					//hyperG.addElement(t, i);
					totAddedElement++;
				}

			}

			ASSERT(hyperId == R);
		}


		//builds an RR seed set for a randomly selected node
		int BuildHypergraphNode(int uStart, int hyperiiid, bool addHyperEdge){
			int n_visit_edge=1;
			if(addHyperEdge)
			{
				ASSERT((int)hyperGT.size() > hyperiiid);
				hyperGT[hyperiiid].push_back(uStart);
			}

			int n_visit_mark=0;
			//for(int i=0; i<12; i++) ASSERT((int)visit[i].size()==n);
			//for(int i=0; i<12; i++) ASSERT((int)visit_mark[i].size()==n);
			//hyperiiid ++;
			q.clear();

			//add first node to q
			q.push_back(uStart);
			ASSERT(n_visit_mark < n);

			visit_mark[n_visit_mark++]=uStart;
			visit[uStart]=true;

			while(!q.empty()) {
				int expand=q.front();

				//using q as stack => doing DFS
				q.pop_front();

				if(influModel==IC){
					int i=expand;
					for(int j=0; j<(int)gT_inferred[i].size(); j++){
						//int u=expand;
						int v=gT[i][j];
						n_visit_edge++;
						double randDouble=double(sfmt_genrand_uint32(&sfmtSeed))/double(RAND_MAX)/2;

						//building a random possible world for this RR set
						if(randDouble > probT_inferred[i][j])
							continue;

						if(visit[v])
							continue;

						if(!visit[v])
						{
							ASSERT(n_visit_mark < n);
							visit_mark[n_visit_mark++]=v;
							visit[v]=true;
						}


						q.push_back(v);
						//#pragma omp  critical 
						//if(0)
						if(addHyperEdge)
						{
							//hyperG[v].push_back(hyperiiid);
							ASSERT((int)hyperGT.size() > hyperiiid);
							hyperGT[hyperiiid].push_back(v);
						}
					}
				}
				else if(influModel==LT){
					if(gT[expand].size()==0)
						continue;
					ASSERT(gT[expand].size()>0);
					n_visit_edge+=gT[expand].size();
					double randDouble=double(sfmt_genrand_uint32(&sfmtSeed))/double(RAND_MAX)/2;
					for(int i=0; i<(int)gT[expand].size(); i++){
						ASSERT( i< (int)probT_inferred[expand].size());
						randDouble -= probT_inferred[expand][i];
						if(randDouble>0)
							continue;
						//int u=expand;
						int v=gT[expand][i];

						if(visit[v])
							break;
						if(!visit[v])
						{
							visit_mark[n_visit_mark++]=v;
							visit[v]=true;
						}
						q.push_back(v);
						if(addHyperEdge)
						{
							ASSERT((int)hyperGT.size() > hyperiiid);
							hyperGT[hyperiiid].push_back(v);
						}
						break;
					}
				}
				else
					ASSERT(false);
			}

			for(int i=0; i<n_visit_mark; i++)
				visit[visit_mark[i]]=false;
			return n_visit_edge;
		}

		//return the number of edges visited
		int64 hyperId = 0;
		deque<int> q;
		sfmt_t sfmtSeed;
		set<int> seedSet;

		//finds the optimal seed set for maximizing influence given the generated RR sets
		void BuildSeedSet(int sel_seeds) {
			vector< int > degree;
			vector< int> visit_local(hyperGT.size());
			//sort(ALL(degree));
			//reverse(ALL(degree));
			seedSet.clear();

			//degree gives the number of RR sets a given node is involved in		
			double temp; 
			int RRset_index;
			int uStart;
			for(int i=0; i<n; i++)
			{
				temp = 0;
				for(int j = 0 ; j < (int)(hyperG[i].size()) ; j++)
				{
					RRset_index = hyperG[i][j];
					uStart = hyperGT[RRset_index][0];
					temp = temp + reward[ uStart ];
				}
				degree.push_back( temp );

				//degree.push_back( hyperG[i].size());

			}

			ASSERT(sel_seeds > 0);
			ASSERT(sel_seeds < (int)degree.size());

			for(int i=0; i<sel_seeds; i++){
				auto t=max_element(degree.begin(), degree.end());
				int id=t-degree.begin();
				seedSet.insert(id);

				//make degree of selected seed node equal to 0
				degree[id]=0;

				//eliminate all the RR sets in which the node id was involved in
				//t iterates over the RR sets 
				for(int t:hyperG[id]){ 
					if(!visit_local[t]){
						visit_local[t]=true;

						//reduce the degree for nodes involved in that RR set
						for(int item:hyperGT[t]){
							degree[item] = degree[item] - reward[hyperGT[t][0]];
							//degree[item]--;
						}
					}
				}
			}
		}

		//estimates the final influence given the seed set
		double InfluenceHyperGraph(){
			set<int> s;
			for(auto t:seedSet){

				//tt iterates over the RR sets 
				for(auto tt:hyperG[t]){
					//for(int index=hyperG.head[t]; index!=-1; index=hyperG.next[index]){
					//int tt=hyperG.data[index];
					s.insert(tt);
				}
				}
				double inf=(double)n*s.size()/hyperId;
				return inf;
			}


			//-------------------   edited ---------------------------------------------------------------//
			map<int,int> IC_true_cov(UserList S, int t_ub, map<int,int> activeNodes, int start_flag) {
				float cov = 0;
				if (t_ub < 0) {
					//cout << "t_ub is 0" << endl;
					exit(0);
				}

				queue<int> Q;

				for (UserList::iterator i=S.begin(); i!=S.end(); ++i) {
					int v = *i;
					//cout << "Seed = " << v << endl;
					Q.push(v);
					// add v to activeNodes. The time step is 0
					if(start_flag == 1)
					{
						activeNodes[v] = 0;
					}
				}

				//cout << "size of active nodes is " << activeNodes.size() << endl;
				while(Q.empty() == false) {
					int v = Q.front(); 
					// get the time step when v is activated
					int timeStep_v = activeNodes[v];

					if (t_ub == 0 || timeStep_v < t_ub) {

						//cout << "degree for node " << v << " is " << gT[v].size() << endl;
						//cout << "degree for node " << v << " is " << inDeg[v] << endl;

						for(int j = 0 ; j < (int)gT_true[v].size(); j++){
							int u = gT_true[v][j];
							if (activeNodes.find(u) == activeNodes.end()) {
								float p = probT_true[v][j];
								//cout << "p is " << p << endl; 
								if (p > 0) {
									activeNodes[u] = timeStep_v + 1;
									Q.push(u);
								}
							}
						}
					}

					Q.pop(); 
				}


#if 0
				for(map<int,int>::iterator j = activeNodes.begin(); j != activeNodes.end() ; ++j)
				{
					cout << "node " << j->first << " is active at time " << j->second  << endl;

				}
#endif

				cov += (float)activeNodes.size();
				return activeNodes;
			}


			void BuildFinalSeedSet(int sel_seeds, int is_adaptive, map<int,int> activeNodes, int regenerate_flag) {
				vector< int > degree;
				vector< int> visit_local(hyperGT.size());

#if DEBUG	 
				cout << "number of RR sets is " << hyperGT.size() << endl;
#endif

				//sort(ALL(degree));
				//reverse(ALL(degree));
				seedSet.clear();
				double temp;
				int uStart;
				int RRset_index;

				//degree gives the number of RR sets a given node is involved in		
				for(int i=0; i<n; i++)
				{
					//degree.push_back( hyperG[i].size() );
					temp = 0;
					for(int j = 0 ; j < (int)(hyperG[i].size()) ; j++)
					{
						RRset_index = hyperG[i][j];
						uStart = hyperGT[RRset_index][0];
						temp = temp + reward[ uStart ];
					}

				}


				if(regenerate_flag == 0)
				{
					//reduce the degree and eliminate the RR sets the active nodes are involved in 
					for( map<int,int>::iterator j = activeNodes.begin() ; j != activeNodes.end() ; ++j)
					{
						degree[j->first] = 0;
						for(int t:hyperG[j->first]){ 
							if(!visit_local[t]){
								visit_local[t]=true;
							}
							//reduce the degree for nodes involved in that RR set
							for(int item:hyperGT[t]){
								degree[item] = degree[item] - reward[ hyperGT[t][0] ];
							}
						}

					}
				}	    	   


				for(int i=0; i < sel_seeds ; i++){

					auto t=max_element(degree.begin(), degree.end());

#if DEBUG
					// find number of duplicates with same degree
					int max_degree = degree[t - degree.begin()];
					int dupl = 0;

					cout << "Degree of max element is " << max_degree << endl;

					for( vector<int>::iterator j = degree.begin(); j != degree.end() ; ++j )
					{
						if(degree[j - degree.begin()] == max_degree)	
							dupl++;

					}

					cout << "Number of elements having degree equal to max is " << dupl << endl;

#endif

					int id=t-degree.begin();
					seedSet.insert(id);

					//make degree of selected seed node equal to 0
					degree[id]=0;

					//eliminate all the RR sets in which the node id was involved in
					//t iterates over the RR sets 
					for(int t:hyperG[id]){ 
						if(!visit_local[t]){
							visit_local[t]=true;

							//reduce the degree for nodes involved in that RR set
							for(int item:hyperGT[t]){
								degree[item] = degree[item] - reward[ hyperGT[t][0] ];
							}
						}
					}
				}
			}


			//-------------------   edited ---------------------------------------------------------------//

		};



