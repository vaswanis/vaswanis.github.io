#include "common.h"

#include <gsl/gsl_math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <omp.h>

class TimGraph: public InfGraph
{
	public:
		TimGraph(string folder, string graph_file, map<string,float> parameters ):InfGraph(folder, graph_file, parameters ){
		}

		//gives the width of an RR set generate for a randomly selected node u
		double MgT(int u){
			//static int i=0;
			//i++;
			//TRACE_LINE("mgt", i);
			ASSERT(u>=0);
			ASSERT(u<n);
			return (double)BuildHypergraphNode(u, 0, false);
		}

		void DistPu()
		{
			/*
			for(int i=0; i<100; i++)
			{
				int u=rand()%n;
				for(int j=0; j<10; j++)
				{
					double pu=MgT(u)/m;
					//cout << pu <<" ";
				}
				//cout<<endl;
			}
			*/

		}

		//function to estimate KPT - returns KPT
		int loopEstimateEPT=0;
		double EstimateEPT2(int sel_seeds, vector<int> inactive){
			double lb=1/2.0;
			//double ub=1;
			double c=0;
			int64 lastR=0;

			while(true){

				int loop= (6 * log(n)  +  6 * log(log(n)/ log(2)) )* 1/lb  ;
				c=0;
				lastR=loop;
				IF_TRACE(int64 now=rdtsc());

				double sumMgTu=0;
				for(int i=0; i<loop; i++){

					//chooses a node at random
					int u=rand()%n;

					//generates RR set for that node and estimates
					//the width for that set
					double MgTu=MgT(u);
					double pu=MgTu/m;

					sumMgTu+=MgTu;

					//c = kappar(R)
					c+=1-pow((1-pu), sel_seeds);
					loopEstimateEPT++;
				}
				c/=loop;
				if(c>lb) break;
				//if(lb<0.01)
				//break;
				lb /= 2;
			}
			BuildHypergraphR(lastR, inactive);
			//TRACE_LINE_END();
			return c * n;
		}

		//function for estimating KPT
		//double ept=-1;
		double EstimateEPT(int sel_seeds, vector<int> inactive)
		{
			Timer t(1, "step1");
			double ept=EstimateEPT2(sel_seeds, inactive);
			ept/=2;
			return ept;
		}

		//intermediate function for refining the estimate of KPT
		void BuildHyperGraph2(double epsilon, double ept, vector<int> inactive){
			Timer t(2, "step2" );
			ASSERT(ept > 0);
			//int64 R = 4.0 * n * log(n) / epsilon / epsilon / ept;
			int64 R = (8+2 * epsilon) * ( n * log(n) +  n * log(2)  ) / ( epsilon * epsilon * ept)/4;
			//cout << "Number of RR sets is " << R << endl;
			//R/=100;
			BuildHypergraphR(R, inactive);
		}

		//function to calculate log (n C k )
		double logcnk(int n, int sel_seeds){
			double ans=0;
			for(int i=n-sel_seeds+1; i<=n; i++){
				ans+=log(i);
			}
			for(int i=1; i<=sel_seeds; i++){
				ans-=log(i);
			}
			return ans;
		}

		//function to generate required number of RR sets for spread estimation
		void BuildHyperGraph3(double epsilon, double opt, int sel_seeds, vector<int> inactive){
			Timer t(3, "step3");
			ASSERT(opt > 0);
			//int64 R = 16.0 * k * n * log(n) / epsilon / epsilon / opt;
			// estimate of the number of RR sets needed to get the error within
			// epsil0n; corresponds to equation 4 in the paper
			int64 R = (8+2 * epsilon) * ( n * log(n) + n * log(2) +  n * logcnk(n, sel_seeds) ) / ( epsilon * epsilon * opt);

			BuildHypergraphR(R, inactive);
		}


		int analyze_spread(map<int,int> activeNodes, string filename)
		{
			ofstream dumpFile (filename.c_str(), ios::app);

			for(map<int,int>::iterator j = activeNodes.begin(); j != activeNodes.end() ; ++j){
				dumpFile << j->first << "," << j->second << endl;
			}
		
			dumpFile << "---------------------------------- " << endl;

			dumpFile.close();

			return 0;
		}


		//function to refine KPT - corresponds to algorithm 3 in the paper	
		int EstimateOPT(map<string, float> parameters, int is_bandit, int round, int is_exploit) {

			double ep_step2, ep_step3;
			double ept;		

			float epsilon = parameters["epsilon"];
			int T = parameters["horizon"];
			int learning_procedure = parameters["learning_procedure"];
			int k = parameters["k"];

			//for Thompson sampling
			const gsl_rng_type * TS;
			gsl_rng * r_TS;
			gsl_rng_env_setup();
 
			TS = gsl_rng_default;
			r_TS = gsl_rng_alloc (TS);

			map<int, int> activeNodes;
			UserList seedSet_union;

			vector<int> inactive;
			vector<int>::iterator it;
			it = inactive.begin();

			for(int i = 0 ; i < n  ; i++)
			{
				it = inactive.insert(it , i);
			}


			
			//updating the rewards based on Ti
			if( parameters["bandit_mode"] == -2 )
			{
				for(int i = 0 ; i < n ; i++ )
				{
					reward[i] = 0;
					for( int j = 0 ; j < (int)(Ti[i].size()) ; j++ )
					{
						reward[i] = reward[i] + (float)(1) / ( Ti[i][j] + 1 );	
					}
		
				}
			}
			

			//finds the optimal seed set for IM 
				if( is_exploit == 1 || is_bandit == 0)
				{
#if DEBUG
					cout << "Exploiting" << endl;
#endif
					seedSet.clear();
					seedSet_union.clear();

					//find optimal seed set - exploitation
					ep_step2=ep_step3=epsilon;
					ep_step2=5*pow(sqr(ep_step3)/k, 1.0/3.0);
					ept=EstimateEPT(k,inactive);
					BuildSeedSet(k);
					//get KPT+ (ept) from KPT (ept)
					BuildHyperGraph2(ep_step2, ept,inactive);
					ept=InfluenceHyperGraph();
					ept/=1+ep_step2;
					//estimates the number of RR sets required and generates them
					BuildHyperGraph3(ep_step3, ept,k,inactive);
					seedSet.clear();
					//find final seed set
					BuildSeedSet(k);
					
				}

				else
				{
#if DEBUG
					cout << "Exploring" << endl;
#endif

					seedSet.clear();
					//find random seed set - exploration
					ep_step2=ep_step3=epsilon;
					ep_step2=5*pow(sqr(ep_step3)/k, 1.0/3.0);
					ept=EstimateEPT(k,inactive);
					BuildSeedSet(k);
					//get KPT+ (ept) from KPT (ept)
					BuildHyperGraph2(ep_step2, ept,inactive);
					ept=InfluenceHyperGraph();
					ept/=1+ep_step2;
					//estimates the number of RR sets required and generates them
					BuildHyperGraph3(ep_step3, ept,k,inactive);

					seedSet.clear();
					//choose a final seed set at random
					if( parameters["bandit_mode"] != 7 )
					{
						random_shuffle ( inactive.begin(), inactive.end() );
						for(int i = 0 ; i < k ; i++)
						{
							seedSet.insert(inactive[i]);
						}
					}

					else
					{
						//high degree
						std::priority_queue<std::pair<double, int>> q;
						for (int i = 0; i < n; ++i) {
							    q.push(std::pair<double, int>(outDeg[i], i));
						 }

  						for (int i = 0; i < k; ++i) {
							int ki = q.top().second;
							seedSet.insert( ki );
    							q.pop();
						}

					}


				}

				//cout << "Expected spread: " << InfluenceHyperGraph() << endl;
				activeNodes = IC_true_cov(seedSet, T, activeNodes, 1);

				//write seed set to file
#if PLOT
				string filename;
				if(is_bandit == 0)
				{
					filename = "NA_known_seeds.txt";   
				}
				else
				{
					filename = "NA_bandit_seeds.txt";
				}


				ofstream seedFile (filename.c_str(), ios::app);
				for(UserList::iterator j = seedSet.begin() ; j != seedSet.end() ; j++) {
					seedFile << *j <<  " " ;		

				}
				seedFile << endl;
				seedFile.close();
#endif 

#if PLOT
				if(is_bandit == 0)
				{
					analyze_spread(activeNodes, "NA_known_spread.txt");
				}
				else
				{					
					analyze_spread(activeNodes, "NA_bandit_spread.txt");
				}
#endif

			// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- //
			if(is_bandit == 1)
			{

				// --------------------   incrementing Xi,Ti for all the edges coming out of active nodes  ------------------------------------- //
				//assuming the true world to be known - EL
				if(learning_procedure == 0)
				{
					for( map<int,int>::iterator j = activeNodes.begin() ; j != activeNodes.end() ; ++j ) {

						//incrementing Ti
						for(unsigned int i = 0 ; i < Ti[j->first].size() ; i++)
						{
							Ti[j->first][i]++;

							//incrementing Xi for the live edges out of the active nodes
							int p = probT_true[j->first][i];
							if(p > 0)
							{
								Xi[j->first][i]++;
							}

						}

					}
				
				}


				// ------------------------------------------------------------------------------------------------------------------------------ //
				//correct method - not assuming anything about the true world - using only the timestamp data
				// ------------------------------------------------------------------------------------------------------------------------------ //
				else if( learning_procedure == 1 )
				{

					int temp = 0;

					fill(visited_node.begin(), visited_node.end(), 0);
					vector<int> indices;
					for(unsigned int i = 0 ; i < activeNodes.size() ; i++)
					{
						indices.push_back(i);
					}

					random_shuffle( indices.begin(), indices.end() );

					for( unsigned int kk = 0 ; kk < activeNodes.size() ; kk++)
					{
						map<int,int>::iterator j = activeNodes.begin(); 
						advance(j,indices[kk]);

						for(unsigned int i = 0 ; i < Ti[j->first].size() ; i++) {

							Ti[j->first][i]++;
							int timestep = j->second;
							int v = gT_true[j->first][i];

							if ( activeNodes.find(v) != activeNodes.end() ) {
								//v is active			
								//cout << "Node " << v << " is active at time " << activeNodes[v] << endl;

								if( activeNodes[v] == timestep + 1)
								{
									//cout << "Inside" << endl;
									if( visited_node[ v ] == 0 )
									{
										Xi[j->first][i]++;
										visited_node[ v ] = 1;
									}
									else
									{						
										temp++;	
#if DEBUG
										//cout << "Clash" << endl;									
#endif
									}

								}
							}
	
						}

					}

					num_clashes = num_clashes + (float)(temp) / activeNodes.size();				

				}

				// ------------------------------------------------------------------------------------------------------------------------------ //

				// ------------------------------------------------------------------------------------------------------------------------------ //
				if(learning_procedure == 0 || learning_procedure == 1)
				{

						if(parameters["use_prior"] == 1)
						{

							//with prior 
							if( ( parameters["bandit_mode"] != 2 ) && ( parameters["bandit_mode"] != 3 ) ) 
							{				

								//for pure exploitation, initial exploitation and epsilon greedy
								for( int j = 0 ; j < n ; j++ )   
	
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
										probT_learnt[j][i] = ((float)(Xi[j][i]) + parameters["prior_alpha"] )/ (Ti[j][i] + parameters["prior_alpha"] + parameters["prior_beta"] ); 
									}
			
								} 

							}

							else if( parameters["bandit_mode"] == 3)
							{
								//for Thompson Sampling								
								for( int j = 0 ; j < n ; j++ )   
	
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
										probT_learnt[j][i] = gsl_ran_beta(r_TS, Xi[j][i] + parameters["prior_alpha"], Ti[j][i] - Xi[j][i] + parameters["prior_beta"] );
									}
			
								} 

							}
							
	
							else
							{

								//for CUCB
								for( int j = 0 ; j < n ; j++ )   
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
									probT_learnt[j][i] = ((float)(Xi[j][i]) + parameters["prior_alpha"] )/ (Ti[j][i] + parameters["prior_alpha"] + parameters["prior_beta"] )+  sqrt((3 * log(round+1)) / ( 2 * Ti[j][i] + parameters["prior_alpha"] + parameters["prior_beta"]) ) ;

										if( probT_learnt[j][i] > parameters["UCB_pmax"] )
										{
											probT_learnt[j][i] = parameters["UCB_pmax"];
										}

									}			
								} 

							}
			
						}

						else
						{
							//no prior
							if( ( parameters["bandit_mode"] != 2 ) && ( parameters["bandit_mode"] != 3 ) ) 
							{
								//for pure exploitation, initial exploitation and epsilon greedy
								for( int j = 0 ; j < n ; j++ )   
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
										if(Ti[j][i] != 0)
										{
											probT_learnt[j][i] = ((float)(Xi[j][i]) ) / ( Ti[j][i] ); 
		
										}
									}
	
								}
							}
						
							
							else if( parameters["bandit_mode"] == 3)
							{
								//for Thompson Sampling								
								for( int j = 0 ; j < n ; j++ )   
	
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
										if( Ti[j][i] != 0)
										{
											probT_learnt[j][i] = gsl_ran_beta(r_TS, Xi[j][i], Ti[j][i] - Xi[j][i] );
										}
									}
			
								} 

							}


							else
							{
								//for CUCB					
								for( int j = 0 ; j < n ; j++ )   
								{
									for( unsigned int i = 0 ; i < probT_learnt[j].size() ; i++)
									{
										if(Ti[j][i] != 0)
							{
							     probT_learnt[j][i] = ((float)(Xi[j][i]) ) / ( Ti[j][i] ) +  1 *  sqrt((3 * log(round+1)) / ( 2 * Ti[j][i] ) ) ;
							}

															
										if( probT_learnt[j][i] > 1 )
										{
											probT_learnt[j][i] = 1;
										}

		
									}
								}
							}

						}

						// ------------------------------------------------------------------------------------------------------------------------------ //
						// convert from outgoing edges to incoming edges
						for( int j = 0 ; j < n ; j++)
						{
							for(unsigned int i = 0 ; i < gT[j].size() ; i++)
							{
								int u = gT[j][i];
								vector<int>::iterator it = find( (gT_true[u]).begin(), (gT_true[u]).end(), j );
								int index = it - (gT_true[u]).begin();
								probT_learnt_reverse[j][i] = probT_learnt[u][index];
							}

						} 

			}	
			// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- //
				if(learning_procedure == 2)
				{

						//map<int,int> temp_activeNodes;				
						//set<int> check_nodes;
						//set<int> active;
						int node; 
						double grad;
						double theta;	
						
						//temp_activeNodes.clear();
						//check_nodes.clear();
						//active.clear();

						//populating temp active nodes
						/*
						for(int i = 0 ; i < n  ; i++)
						{
							temp_activeNodes[i] = -1;
						}

						for( map<int,int>::iterator it = activeNodes.begin(); it != activeNodes.end() ; ++it )
						{
							node = it->first;
							timestamp = it->second;
							temp_activeNodes[node] = timestamp;	
							active.insert(node);
							check_nodes.insert(node);				
						}
					        */	

						for( map<int,int>::iterator it = activeNodes.begin() ; it != activeNodes.end() ; ++it) 
						{ 	 
							node = it->first;
							int t1 = it->second;

							num_active[node]++;

							//float eta = parameters["initial_eta"] /  ( 1 + parameters["initial_eta"] * powf( (float)(num_active[node]), 0.4 ) ); 
							//float eta = parameters["initial_eta"] /  (  powf( (float)(num_active[node]), 0.5 ) ); 
							double B = 0;
							float lambda = 0;
							//double B = 1;
							double temp;
							int B_size = 0;

							//check all in possible in-neighbours of all active neighbours and solve for the node
							for( unsigned int j = 0 ; j < gT[node].size() ; j++ )
							{
								
								int neighbour = gT[node][j];

								//check if neighbour is an active parent
								map<int,int>::iterator jt = activeNodes.find( neighbour );
								
								if ( jt != activeNodes.end() ) 
								{
									//neighbour is active parent
		
									//get timestamp of active parent
									int t0 = jt->second;			
		
									if( t0 != t1 - 1)
									{
										//parent is active but not responsible for activating node => decrease prob
													
	 									theta = -1 * log( 1 - probT_learnt_reverse[node][j] );
										grad = 1 + lambda * theta;
										temp = sqrt( pow( grad_norm[node][j], 2 ) + pow(grad,2) );
										grad_norm[node][j] = temp;

										float eta = parameters["initial_eta"] / ( grad_norm[node][j] + 1 ) ;									

										theta  =  theta -  (eta) * grad;
										if( theta < 0) theta = 1e-6;
										probT_learnt_reverse[node][j] = 1 - exp( -1 * theta );
										
										/*													
										grad  = ( 1 / ( 1 - probT_learnt_reverse[node][j]  ) ) + lambda * probT_learnt_reverse[node][j]  ;
										temp = sqrt( pow( grad_norm[node][j],2 ) + pow(grad,2) );
										grad_norm[node][j] = temp;
										
										float eta = parameters["initial_eta"] / ( grad_norm[node][j] + 1) ;

										probT_learnt_reverse[node][j] = min( (probT_learnt_reverse[node][j] - ( eta * grad)), 0.99 );
										if( probT_learnt_reverse[node][j] < 0) probT_learnt_reverse[node][j] = 1e-6;
										*/

									}

									else
									{
										//parent is active and responsible for activating node => calculate B
											
										B_size++;		
	 									theta = -1 * log( 1 - probT_learnt_reverse[node][j] );
										B = B + theta;		
										
										/*
										B = B * ( 1 - probT_learnt_reverse[node][j] );
										*/

									}
														

								}
			
							}

							
							//grad = (1 + 1e-10) / ( exp(B) - 1 + 1e-10);
							grad = (1 ) / ( exp(B) );
							//B = 1 - B + 1e-10;
							

							//second loop over active parents
							for( unsigned int j = 0 ; j < gT[node].size() ; j++ )
							{
								
								int neighbour = gT[node][j];

								//check if neighbour is an active parent
								map<int,int>::iterator jt = activeNodes.find( neighbour );
								
								if ( jt != activeNodes.end() ) 
								{
									//neighbour is active parent

									//get timestamp of active parent
									int t0 = jt->second;			
		
									if( t0 == t1 - 1)
									{
										//parent is active and responsible for activating node => calculate B															
										
	 									theta = -1 * log( 1 - probT_learnt_reverse[node][j] );
										grad = (1) / ( exp(B) );

										temp = 1 * grad - lambda * theta;
										grad_norm[node][j] =  sqrt( pow( grad_norm[node][j], 2 ) + pow(temp,2) );
										//float eta = parameters["initial_eta"] / ( grad_norm[node][j] + 1 ) ;									
										float eta = parameters["initial_eta"] ;

										theta  =  theta + (eta) * temp;
										if( theta < 0) theta = 1e-6;
										probT_learnt_reverse[node][j] = 1 - exp( -1 * theta );
										
										/*
										grad = (( (1-B) / B ) / (1 - probT_learnt_reverse[node][j] )) - lambda * probT_learnt_reverse[node][j];

										temp = sqrt( pow(grad_norm[node][j],2) + pow( grad,2) );
										grad_norm[node][j] = temp;										
										float eta = parameters["initial_eta"]  / ( grad_norm[node][j] + 1 ) ;

										probT_learnt_reverse[node][j] = min(( probT_learnt_reverse[node][j] + (eta * grad)), 0.99 );
										if (probT_learnt_reverse[node][j] < 0) probT_learnt_reverse[node][j] = 1e-6;
                                                                                */

										
									}
									
								}

							}

							//check out-neighbours of all active nodes and solve for the inactive ones
							for(int j = 0; j < (int)gT_true_static[node].size(); j++)
							{
								int neighbour = gT_true_static[node][j];
								num_active[neighbour]++;

								//if neighbour not in active - directly reduce probability
								if ( activeNodes.find(neighbour) == activeNodes.end() ) 
								{

										vector<int>::iterator it = find( (gT[neighbour]).begin(), (gT[neighbour]).end(), node );
										int k = it - (gT[neighbour]).begin();									

										//float eta = parameters["initial_eta"] / ( 1 + parameters["initial_eta"] * powf( (float)(num_active[neighbour]), 0.4 ) );
										//float eta = parameters["initial_eta"] / ( powf( (float)(num_active[neighbour]), 0.5 )) ;
										
	 									theta = -1 * log( 1 - probT_learnt_reverse[neighbour][k] );

										grad = 1 + lambda * theta;
										grad_norm[neighbour][k] =  sqrt( pow( grad_norm[neighbour][k], 2 ) + pow(grad,2) );

										//float eta = parameters["initial_eta"] / ( grad_norm[neighbour][k] + 1 ) ;									
										float eta = parameters["initial_eta"] ;
										theta  =  theta -  (eta) * grad;

										if( theta < 0) theta = 1e-6;
										probT_learnt_reverse[neighbour][k] = 1 - exp( -1 * theta );
										
										/*
										grad  = ( 1 / ( 1 - probT_learnt_reverse[neighbour][k] ) ) + lambda * probT_learnt_reverse[neighbour][k]  ;
										temp = sqrt( pow(grad_norm[neighbour][k],2) + pow(grad,2) );
										grad_norm[neighbour][k] = temp;
										float eta = parameters["initial_eta"] / (  grad_norm[neighbour][k] + 1 ) ;
										probT_learnt_reverse[neighbour][k] = min( (probT_learnt_reverse[neighbour][k] - ( eta * grad)) , 0.99 );
										if( probT_learnt_reverse[neighbour][k] < 0) probT_learnt_reverse[neighbour][k] = 1e-6;
										*/
									

								}
							}


						}

						/*
						for( set<int>::iterator it = active.begin() ; it != active.end() ; ++it) 
						{ 	 
							node = *it;
							for(int j = 0; j < (int)gT_true_static[node].size(); j++)
							{
								check_nodes.insert(gT_true_static[node][j]);	
							}
						}
						*/
						/*
						for( set<int>::iterator it = check_nodes.begin() ; it != check_nodes.end() ; ++it) 
						{
	
								node = *it;

								num_active[node]++;
#if DEBUG
								cout << "Solving for node " << node << endl;
								cout << "Neighbourhood size = " << probT_learnt_reverse[node].size() << endl;
#endif	
								probT_learnt_reverse[node] = learn_modified(node, temp_activeNodes, probT_learnt_reverse[node], parameters, round);		
						}
						*/

				}

				if( learning_procedure == 3)
				{
					map<int,int> temp_activeNodes;				
					set<int> active;
					int node; 
					int timestamp;


					temp_activeNodes.clear();
					//populating temp active nodes
					for(int i = 0 ; i < n  ; i++)
					{
						temp_activeNodes[i] = -1;
					}

					for( map<int,int>::iterator it = activeNodes.begin(); it != activeNodes.end() ; ++it )
					{
						node = it->first;
						timestamp = it->second;
						temp_activeNodes[node] = timestamp;	
						active.insert(node);

						//stores a list of nodes involved in at least one cascade
						global_check_nodes.insert(node);
		
						//insert cascade into list of cascades the node was involved in 
						cascades_involved[node].insert(round);
							
					}

					//insert new cascade into list of cascades
					cascades[round] = temp_activeNodes;

					for( set<int>::iterator it = active.begin() ; it != active.end() ; ++it) 
					{ 	 
						node = *it;
						for(int j = 0; j < (int)gT_true_static[node].size(); j++)
						{
							global_check_nodes.insert(gT_true_static[node][j]);	

							int neighbour = gT_true_static[node][j];
							//insert cascade into list of cascades the node was involved in 

							cascades_involved[neighbour].insert(round);
							num_active[neighbour] = (cascades_involved[neighbour]).size();

						}
					}

					//learn for the nodes involved in at least one cascade
					for( set<int>::iterator it = global_check_nodes.begin() ; it != global_check_nodes.end() ; ++it) 
					{
						node = *it;

#if DEBUG
						cout << "Solving for node " << node << endl;
						cout << "Neighbourhood size = " << probT_learnt_reverse[node].size() << endl;
#endif	
						//if( node == 51)
						probT_learnt_reverse[node] = learn_modified_ERM(node, cascades_involved[node], cascades, probT_learnt_reverse[node], parameters, round);		


					}
				}
	
					

			}

	  	        //gives the spread estimate at the end of the diffusion process
			ept=InfluenceHyperGraph();
			disp_mem_usage("");

			hyperGT.clear();
			hyperG.clear();
			seedSet.clear();
			seedSet_union.clear();

			return activeNodes.size();
}


vector<double> calculate_gradient(int node, map<int,int> activeNodes, vector<double> theta)
{
	int neighbourhood_size = (theta).size();
	vector<int> currneighbours_successful;
	vector<int> currneighbours_unsuccessful;
	vector<double> gradient_theta;
	float eps = 1e-8;

	for(int i = 0 ; i < neighbourhood_size; i++)
	{
		currneighbours_successful.insert(currneighbours_successful.end(), 0);
		currneighbours_unsuccessful.insert(currneighbours_unsuccessful.end(), 0);
	}

	if( activeNodes[node] != -1)
	//if(1)
	{
		//node is active
#if DEBUG
		cout << "Node "  << node << " is active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( (activeNodes[neighbour] <= activeNodes[node] - 2) && (activeNodes[neighbour] > -1) )
			{
				//neighbour didn't activate node
				currneighbours_unsuccessful[i] = 1;
			}
			else if( (activeNodes[neighbour] == activeNodes[node] - 1) && (activeNodes[neighbour] > -1))
			{
				//neighbour activated node
				currneighbours_successful[i] = 1;
			}

		}		
	
	}
	
	else
	{
		//node is inactive
#if DEBUG
		cout << "Node "  << node << " is not active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( activeNodes[neighbour] != -1)
			{
				currneighbours_unsuccessful[i] = 1;
			}
		}
	}
	
	long double currthetavalue = 0;
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_theta.insert( gradient_theta.end(), currneighbours_unsuccessful[i] );
		currthetavalue = currthetavalue + ( theta[i] * currneighbours_successful[i] );
	}

	if( (activeNodes[node] != -1) && (activeNodes[node] != 0))
	{
		if( currthetavalue != 0 )
		{
			long double temp = ( ( exp(currthetavalue) - 1 ) );
			if(temp > 1e-8)
			{
				for( int i = 0 ; i < neighbourhood_size ; i++)
				{
					gradient_theta[i] = gradient_theta[i] - ((1/temp) * currneighbours_successful[i]);
				}
			}
		}
		
		else
		{
			for( int i = 0 ; i < neighbourhood_size ; i++)
			{
				gradient_theta[i] = gradient_theta[i] - (eps * currneighbours_successful[i]);
			}
		}
			
	} 

#if DEBUG
	cout << "gradient theta is " << endl;
	for( int i = 0 ; i < neighbourhood_size ; i++)
	{
		cout << gradient_theta[i] << endl; 
	}
#endif


	return gradient_theta;
}


//calculate likelihood
double calculate_likelihood( int node, map<int,int> activeNodes, vector<double> p )
{
	int neighbourhood_size = (p).size();
	double B = 1;
	double LL = 1;
	int flag = 0;

	if( activeNodes[node] != -1)
	{
		//target node v is active
#if DEBUG
		cout << "Node "  << node << " is active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( (activeNodes[neighbour] <= activeNodes[node] - 2) && (activeNodes[neighbour] > -1) )
			{
				//neighbour is active and didn't activate node v; => unsuccessful attempt => neighbour lies in set A
				LL = LL * ( 1 - p[i] ) ; 
			}

			else if( (activeNodes[neighbour] == activeNodes[node] - 1) && (activeNodes[neighbour] > -1))
			{
				//neighbour is active and activated node v => successful attempt => neighbour lies in set B
				flag = 1;
				B = B * (1 - p[i]);
			}

		}

		if (flag == 1)
			LL = LL * ( 1 - B ) ;
	}
	
	else
	{
		//target node v is inactive => unsuccessful attempts from all active neighbours

#if DEBUG
		cout << "Node "  << node << " is not active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( activeNodes[neighbour] != -1)
			{
				//neighbour is active => neighbour lies in set A
				LL = LL *  ( 1 - p[i] );
			}
		}
	}

	return LL;	
}

//calculate gradient 
vector<double> calculate_gradient_modified(int node, map<int,int> activeNodes, vector<double> p)
{

	int neighbourhood_size = (p).size();
	vector<double> gradient_p;
	double B = 1;
	
	//initialize gradient to zero
	for(int i = 0 ; i < neighbourhood_size; i++)
	{
		gradient_p.insert(gradient_p.end(), 0);
	}

	if( activeNodes[node] != -1)
	{
		//target node v is active
#if DEBUG
		cout << "Node "  << node << " is active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( (activeNodes[neighbour] <= activeNodes[node] - 2) && (activeNodes[neighbour] > -1) )
			{
				//neighbour is active and didn't activate node v; => unsuccessful attempt => neighbour lies in set A
				gradient_p[i] = 1 / (1 - p[i]); 
			}
			else if( (activeNodes[neighbour] == activeNodes[node] - 1) && (activeNodes[neighbour] > -1))
			{
				//neighbour is active and activated node v => successful attempt => neighbour lies in set B
				B = B * ( 1 - p[i] );

			}

		}

		B = 1 - B;			

		// second loop over neighbours in set B
		for( int i = 0 ; i < neighbourhood_size ; i++ )
		{
			
			int neighbour = gT_inferred[node][i];					
			if( (activeNodes[neighbour] == activeNodes[node] - 1) && (activeNodes[neighbour] > -1))
			{
				// for nodes in set B
				gradient_p[i] = ((B - 1) / B) / ( 1 - p[i] );
			}

		}

	}
	
	else
	{
		//target node v is inactive => unsuccessful attempts from all active neighbours
#if DEBUG
		cout << "Node "  << node << " is not active " << endl;
#endif
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			int neighbour = gT_inferred[node][i];
			if( activeNodes[neighbour] != -1)
			{
				//neighbour is active => neighbour lies in set A
				gradient_p[i] = 1 / ( 1 - p[i] );
			}
		}
	}


#if DEBUG
	cout << "gradient p is " << endl;
	for( int i = 0 ; i < neighbourhood_size ; i++)
	{
		cout << gradient_p[i] << endl; 
	}
#endif


	return gradient_p;
}


//---------------------------------------------------------------------------------------------------------- //
vector<double> learn(int node, map<int,int> activeNodes, vector<double>  p, map<string, float> parameters, int round)
{
vector<double> theta;
vector<double> old_theta;
vector<double> new_p;
vector<double> gradient_theta;
vector<double> temp;

int neighbourhood_size = p.size();
float eta = parameters["initial_eta"]; // / sqrt(num_active[node]); 

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	theta.insert( theta.end(),  -1 * log( 1 - p[i]  ) );
	old_theta.insert( old_theta.end(),  -1 * log( 1 - p[i]  ) );
	gradient_theta.insert(gradient_theta.end(), 0);
	temp.insert( temp.end(), 0 );
}


for(int i = 0 ; i < neighbourhood_size ; i++)
{
	gradient_theta[i] = 0;
}

gradient_theta = calculate_gradient(node,activeNodes,theta);

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	theta[i] = theta[i] - ( eta * gradient_theta[i] ); 
	if(theta[i] < 0)
	{
		theta[i] = 0;
	}
}

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	new_p.insert(new_p.end(), 1 - exp(-1 * theta[i] ));
}

return new_p;

}


vector<double> learn_modified(int node, map<int,int> activeNodes, vector<double>  p, map<string, float> parameters, int round)
{
vector<double> new_p;
vector<double> gradient_p;
vector<double> temp;

int neighbourhood_size = p.size();

#if DEBUG
cout << "Num active is " << num_active[node] << endl;
#endif

float eta = parameters["initial_eta"] / ( 1 + parameters["initial_eta"] * powf( (float)(num_active[node]), 0.5 ) ); 
//float eta = parameters["initial_eta"] / ( 1 + powf( (float)(num_active[node]), 1 ) ); 
//float eta = parameters["initial_eta"] ; 

gradient_p = calculate_gradient_modified(node,activeNodes,p);

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	gradient_p.insert(gradient_p.end(), 0);
	temp.insert(temp.end(),0);

	temp[i] = p[i] - ( eta * gradient_p[i] ); 

	if( temp[i] < 0 )
	{
#if DEBUG
		cout << "Projection to 0" << endl;
#endif
		temp[i] = 0;
	}
	
	if( temp[i] > 1)
	{
#if DEBUG
		cout << "Projection to 1" << endl;
#endif
		temp[i] = 0.99;
	}
}

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	new_p.insert(new_p.end(), temp[i] );
}

return new_p;

}

vector<double> learn_modified_ERM(int node, set<int> cascades_involved, map<int,map<int,int>> cascades, vector<double>  p, map<string, float> parameters, int round)
{
vector<double> new_p;
vector<double> old_p;
vector<double> gradient_p;
vector<double> temp;
map<int,int> activeNodes;

int iterations = 50;
int max_bt_iter = 50;
float optTol = 1e-2;
float optGrad = 1e-2;
float alpha_decrement = 0.7;
float alpha = 0.1;

float org_alpha;
float diff;
int flag = 0;
int bt_flag = 0;
double LL = -1;
double old_LL = 0;
float g_l2_norm = 0;

int neighbourhood_size = p.size();
set <int>::iterator s_iter;

#if DEBUG
cout << "Num active is " << num_active[node] << endl;
#endif

//initialize likelihood
old_LL = 1;
for(s_iter=cascades_involved.begin() ; s_iter != cascades_involved.end(); ++s_iter)
{
	int cascade_id = *s_iter;
	activeNodes = cascades[cascade_id];
	old_LL = old_LL * calculate_likelihood(node,activeNodes,p);
}

#if DEBUG
cout << "Original Likelihood:  " << old_LL << endl;
#endif

//initialize
for(int i = 0 ; i < neighbourhood_size ; i++)
{
	temp.insert(temp.end(), 0 );
	gradient_p.insert(gradient_p.end(), 0 );
	old_p.insert( old_p.end(), p[i] );
	
}

//initialize step size
org_alpha = alpha;

for(int iter = 0 ; iter < iterations ; iter ++)
{
	//initalize gradient and its l2 norm
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_p[i] = 0;
	}
	g_l2_norm = 0;
	diff = 0;

	//calculate gradient
	for(s_iter=cascades_involved.begin() ; s_iter != cascades_involved.end(); ++s_iter)
	{
		int cascade_id = *s_iter;
		activeNodes = cascades[cascade_id];
		temp = calculate_gradient_modified(node,activeNodes, p);

		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			gradient_p[i] = gradient_p[i] + temp[i];	
		}
	}

	//normalize gradient and calculate its l2 norm 
	for(int i = 0 ; i < neighbourhood_size ; i++)
	{
		gradient_p[i] = gradient_p[i] / cascades_involved.size();
		g_l2_norm = g_l2_norm + powf( gradient_p[i],2);
	}

	//check for termination
	g_l2_norm= sqrt(g_l2_norm);

	#if DEBUG
		cout << "Gradient norm = " << g_l2_norm << endl;
	#endif

	if( g_l2_norm < optGrad )
	{
		#if DEBUG
		cout << "Converged in " << iter << " iterations "  << endl;
		#endif

		flag = 1;
		break;
	}

	//bt_flag = 1;
		
	//setting up back tracking line search
	alpha = org_alpha;
	LL = -1;
	bt_flag = 0;

	//back tracking linesearch
	for( int bt = 0 ; bt < max_bt_iter ; bt++)
	{
		#if DEBUG
		cout << "Inside linesearch iter " << bt << endl;
		#endif

		//take gradient step
		for(int i = 0 ; i < neighbourhood_size ; i++)
		{
			p[i] = old_p[i] - ( alpha * gradient_p[i] ) ;

			if(p[i] < 0)
			{
				p[i] = 0;
			}

			if( p[i] > 1 )
			{
				p[i] = 0.99;
			}

		}
	

		LL = 1;
		for(s_iter=cascades_involved.begin() ; s_iter != cascades_involved.end(); ++s_iter)
		{
			int cascade_id =  *s_iter;
			activeNodes = cascades[cascade_id];
			LL = LL * calculate_likelihood(node,activeNodes,p);
		}

		#if DEBUG
		cout << "LL in backtracking linesearch: " << LL << endl;
		#endif

		//backtracking
		if( LL > old_LL )
		{
			//successful step
			bt_flag = 1;
			break;
		}
		
		//step size is too aggressive
		alpha = alpha * alpha_decrement;

	}
	

	if( bt_flag == 1)
	{
		for( int i = 0 ; i < neighbourhood_size ; i++)
		{
			diff = diff + pow( ( old_p[i] - p[i] ),2);
			old_p[i] = p[i];
		}
		
		old_LL = LL;

		#if DEBUG
		cout << "Likelihood in iteration " <<  iter << " : " << LL << endl;
		#endif
	
		diff = sqrt(diff);

		#if DEBUG
		cout << "Difference in parameter values = "  << diff << endl;
		#endif
	
		if( diff < optTol )
		{
			flag = 1;

			#if DEBUG
			cout << "Converged in " << iter << " iterations "  << endl;
			#endif
			break;
		}
	}
	else
	{
		#if DEBUG
		cout << "Unsuccessful Backtracking line search" << endl;
		#endif
		break;
	}
}

if( flag == 0)
{
	#if DEBUG
	cout << "Reached max iterations" << endl;
	#endif
}

for(int i = 0 ; i < neighbourhood_size ; i++)
{
	new_p.insert(new_p.end(), old_p[i] );
}

return new_p;

}

};

			
