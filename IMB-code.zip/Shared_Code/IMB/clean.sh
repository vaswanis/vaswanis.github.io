rm -rf NA_final_Ti_vals.txt
rm -rf NA_final_Xi_vals.txt
rm -rf NA_final_probT_learnt_vals.txt
rm -rf NA_bandit_times.txt

rm -rf A_final_Ti_vals.txt
rm -rf A_final_Xi_vals.txt
rm -rf A_final_probT_learnt_vals.txt
rm -rf A_bandit_times.txt

rm -rf A_known_seeds.txt
rm -rf A_known_spread.txt
rm -rf A_known_times.txt

rm -rf NA_known_seeds.txt
rm -rf NA_known_spread.txt

rm -rf A_bandit_seeds.txt
rm -rf A_bandit_spread.txt

rm -rf NA_bandit_seeds.txt
rm -rf NA_bandit_spread.txt

rm -rf log.txt
