g++ src/tim.cpp -Wall -lgsl -lgslcblas -lm -std=c++0x -O3 src/sfmt/SFMT.c  -o tim
