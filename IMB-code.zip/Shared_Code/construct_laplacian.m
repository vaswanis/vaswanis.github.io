function [L] = construct_laplacian(A)

n = size(A,1);
d = sum(A,2);
D = sparse(diag(d));
L = D - A;

L = L + 1 * speye(n);

end
