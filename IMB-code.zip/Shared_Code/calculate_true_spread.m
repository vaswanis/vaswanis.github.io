function [spread active] = calculate_true_spread(S,draw)

n = size(draw,1);
K = size(S,1);

%initialize activated set
activated = zeros(n,K);

%initialize all activated set
all_activated = zeros(n,1);

%check reachability from any source node
for j = 1:K
    [d,~,~] = bfs(draw,S(j));
    activated(:,j) = (d ~= -1);
end

% activated contains indices of nodes reachable from s
for j = 1:K
    all_activated = bitor(all_activated,activated(:,j));
end

spread = nnz(all_activated);
active = find(all_activated ~= 0);

end
