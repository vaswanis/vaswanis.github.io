function [A,P,component_sizes] = create_graph(n,pmax, C,type)


if type == 1
    
    A = sparse(n,n);
    %create random unweighted Erdos Renyi graph
    p = 0.01;
    [G]=erdosRenyi(n,p,1);
    A = G.Adj;
    
    %create weighted graph following the structure 
    P = rand(n) .* A * pmax;
    
    component_sizes = 0;
    
elseif type == 2
    
    A = sparse(n,n);
    %create forest fire graph
    edgeList = adjL2edgeL(forestFireModel(n,0.2,1));
    m = size(edgeList,1);
    for i = 1:m
        out  = edgeList(i,1);
        in  = edgeList(i,2);
        A(out, in) = 1;
    end
    
    %create weighted graph following the structure
    P = rand(n) .* A * pmax;
    component_sizes = 0;
    
elseif type == 3
    
    A = sparse(n,n);
    
    % create graph of disjoint communiities
    P = sparse(n,n);
    
    component_sizes = zeros(C,1);
    p = rand(C,1);
    p = p / sum(p);
    
    for i = 1:C-1
        component_sizes(i) = floor(p(i) * n);
    end
    component_sizes(C) = n - sum(component_sizes);

    current = 1;
    for i = 1:C
        
        A(current:current+component_sizes(i)-1,current:current+component_sizes(i)-1) = ones(component_sizes(i));
        P(current:current+component_sizes(i)-1,current:current+component_sizes(i)-1) = rand * pmax * ones(component_sizes(i));
        current = current + component_sizes(i);
        
    end
    
elseif type == 4

    scale = floor(log2(n));
    
    sparsity = 0.03;
    ij = kronecker_generator (scale, sparsity);
    A = sparse ( ij(1,:)+1, ij(2,:)+1, size(ij,2), n , n  );
    A = bsxfun(@or,A,eye(n));

    A = sparse(A);
    P = rand(n) .* A * pmax;

    component_sizes = 2^(scale);

    % 2 community graph - to compare against MAB
    %P = sparse(n,n);
    %c1 = round(0.4 * n);
    %component_sizes = [c1 ; n - c1];
    %Pr = [1 ; 0.99];
    
    %current = 1;
    %for i = 1:2
        
    %    A(current:current+component_sizes(i)-1,current:current+component_sizes(i)-1) = ones(component_sizes(i));
    %    P(current:current+component_sizes(i)-1,current:current+component_sizes(i)-1) = Pr(i) * ones(component_sizes(i));
    %    current = current + component_sizes(i);
        
    % end
    
elseif type == 5
    
    fname = './Data/facebook/graph_ic.inf';
    edges = dlmread(fname);
    n = max(edges(:));
    
    A = sparse(n,n);
    P = sparse(n,n);
    
    for e = 1:size(edges,1)
        out = edges(e,1);
        in = edges(e,2);
        p = edges(e,3);
        
        A(out,in) = 1;     
        P(out,in) = rand * pmax;
    end
    
     component_sizes = n;
     
elseif type == 6

    fname = 'Data/nethept/graph_ic.inf';
    edges = dlmread(fname);
    n = max(edges(:));
    
    A = sparse(n,n);
    P = sparse(n,n);
    
    for e = 1:size(edges,1)
        out = edges(e,1);
        in = edges(e,2);
        p = edges(e,3);
        
        A(out+1,in+1) = 1;     
        P(out+1,in+1) = p;
    end
    
     component_sizes = n+1;

elseif (type == 7)
    
    
    fname = 'Data/facebook-combined/graph_ic.inf';
    edges = dlmread(fname);
    n = max(edges(:));
    
    A = sparse(n+1,n+1);
    P = sparse(n+1,n+1);

    in_degree = zeros(n+1);
    
    for e = 1:size(edges,1)
        out = edges(e,1);
        in = edges(e,2);
        
	in_degree(in+1) = in_degree(in+1) + 1;

        A(out+1,in+1) = 1;     

	if pmax > 0
	        P(out+1,in+1) = rand * pmax;
	end

    end

   if pmax == 0

	   for e = 1:size(edges,1)
	        out = edges(e,1);
	        in = edges(e,2);
	        P(out+1,in+1) = 1 / (in_degree(in+1)); 
	   end   
 
   end

   component_sizes = n+1;
    
elseif type == 8
    
    
    fname = 'Data/flixster/graph_ic.inf';
    edges = dlmread(fname);
    n = max(edges(:));
    
    A = sparse(n+1,n+1);
    P = sparse(n+1,n+1);
    
    for e = 1:size(edges,1)
        out = edges(e,1);
        in = edges(e,2);
        p = edges(e,3);
        
        A(out+1,in+1) = 1;     
        P(out+1,in+1) = p;
    end
    
     component_sizes = n+1;

elseif (type == 9)
    
    
    fname = 'Data/wiki/graph_ic.inf';
    edges = dlmread(fname);
    n = max(edges(:));
    
    A = sparse(n+1,n+1);
    P = sparse(n+1,n+1);
    
    for e = 1:size(edges,1)
        out = edges(e,1);
        in = edges(e,2);
        
        A(out+1,in+1) = 1;     
        P(out+1,in+1) = rand * pmax;
    end
    
     component_sizes = n+1;
    
else
    
    disp('Error: Not valid type\n');
    
end

end

