import os
import sys
import random

fname = sys.argv[1]
gname = sys.argv[2]
delim = int(sys.argv[3])
pmax = float(sys.argv[4])

if delim == 0:
	delimiter = ' '
else:
	delimiter = '\t'

f = open(fname,'r')
g = open(gname,'w')
s = f.readlines()

in_degree = {}
for i in range(len(s)):
	t = s[i].rstrip()
	l = str.split(t, delimiter)
	in_node = int(l[1])

	if in_degree.has_key(in_node):
		in_degree[in_node] = in_degree[in_node] + 1
	else:
		in_degree[in_node] = 1

print in_degree

for i in range(len(s)):

	t = s[i].rstrip()
		
	#generate random activation probability
	p = random.uniform(0,pmax)

	#generate constant activation probability
	#p = 0.01;

	#generate activation probability inversely proportional to degree
	
	l = str.split(t, delimiter)
	in_node = int(l[1])
	out_node = int(l[0])

	t = str(out_node) + ' ' + str(in_node) + '\n'

	#p = 1 / float(in_degree[in_node])
	

	#t = t + ' ' +  str(p) + '\n'

	g.write(t)


g.close()
f.close()
