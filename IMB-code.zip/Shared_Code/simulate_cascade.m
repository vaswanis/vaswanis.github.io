function [draw] = simulate_cascade(A,P)

%simulate cascades under the IC model
n = size(A,1);

%random draw of the graph
toss = rand( nnz(P),1 );
nnz_indices = find(P ~= 0);
draw = sparse(n,n);
draw( nnz_indices ) = (toss < P(nnz_indices));

end
