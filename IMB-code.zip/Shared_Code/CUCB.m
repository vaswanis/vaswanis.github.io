function [cascades, CUCB_spread,CUCB_time] = CUCB(dataset, K, T,diffusion_model,spread_computation_model)

% need to change the config file to incorporate command line args
modify_CUCB_config(dataset,K, T,diffusion_model, spread_computation_model);

% run CUCB 
cascades_fname = ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_cascades.txt'];
results_fname =  ['./Results/' dataset '_' num2str(K) '_' num2str(T) '_CUCB_results.log'];

cmd = ['./IMB/tim ./IMB/config.txt | tee  ' results_fname];
system(cmd);

disp('CUCB finished');

% process cascades
[ cascades ] = process_cascades( cascades_fname, T );

% process results
[CUCB_spread,CUCB_time] = process_CUCB_results(results_fname);

%CUCB_spread = 0;
%CUCB_time = 0;

end
